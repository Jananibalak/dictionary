  
  function loadJSON(){
  
      var data_file = "/Dictionary/JavaScript/countries.json";
      var http_request = new XMLHttpRequest();
      try{
         // Opera 8.0+, Firefox, Chrome, Safari
         http_request = new XMLHttpRequest();
      }catch (e){
         // Internet Explorer Browsers
         try{
            http_request = new ActiveXObject("Msxml2.XMLHTTP");
				
         }catch (e) {
			
            try{
               http_request = new ActiveXObject("Microsoft.XMLHTTP");
            }catch (e){
               // Something went wrong
               alert("Your browser broke!");
               return false;
            }
				
         }
      }
		
      http_request.onreadystatechange = function(){
    	
         if (http_request.readyState == 4  ){
        	 
            // Javascript function JSON.parse to parse JSON data
     
           
            var jsonObj = eval(http_request.responseText);
            //alert(http_request.responseText);
            // jsonObj variable now contains the data structure and can
            // be accessed as jsonObj.name and jsonObj.country.
           // document.getElementById("Name").innerHTML = jsonObj.name;
              
            // document.getElementById("Country").innerHTML = jsonObj.country;

      	 
             
           for (var i = 0; i < jsonObj.length; i++) {
          	
          	 var object = jsonObj[i];
          	  
          	   
          	 var x = document.createElement("OPTION");
          	
          	    x.setAttribute("value", object["name"]);
          	    var t = document.createTextNode(object["name"]);
          	    x.appendChild(t);
          	    document.getElementById("country").appendChild(x);

// If property names are known beforehand, you can also just do e.g.
// alert(object.id + ',' + object.Title);
             }
         }
      }
		
      http_request.open("GET", data_file, true);
      http_request.send();
   }

function onFinish()
{
	var name=document.getElementById('name').value;
	var password=document.getElementById('pwd').value;
	var ppattern1='[0-9]';
	var ppattern2='[a-zA-z]';
	if(name=="")
		{
		document.getElementById('name').focus();
		
			
		alert("enter Name");
	return false;
		}
	else
	{
		if(name.length>20){
			alert("Limit the no. of characters to 20(Name)");return false;}
		if(name.length<4){
			alert("Minimum limit of characters is 6(Name)");return false;}
		if(/[0-9]/.test(name)){
			alert("Please do not include digits in your name");return false;}
		
		
	}	
	if(document.getElementById('email').value=="")
	{
	document.getElementById('email').focus();
	alert("enter EmailId");
	return false;
	}
	if(!(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$/.test(document.getElementById('email').value)))
		{
		alert("Pattern of EmailId is invalid");
		return false;
		
		}
	if(password=="")
	{
	document.getElementById('pwd').focus();
	
	alert("enter password");
	return false;

	}
	else
		{
		if(password.length>20){
			alert("Limit the no. of characters to 20(password)");return false;}
		if(password.length<4){
			alert("Minimum limit of characters is 6(password)");return false;}
		if(!(/[a-z]/.test(password))){
			alert("Include LOWERCASE in your password");return false;}
		if(!(/[0-9]/.test(password))){
			alert("Include digits in your password");return false;}
		if(!(/[A-Z]/.test(password))){
			alert("Include UPPERCASE in your password");return false;}
	
	
		}

 if(document.getElementById('cpwd').value=="")
	{
	document.getElementById('cpwd').focus();
	alert("confirm your password");
	return false;
	
	}

	else if(document.getElementById('country').value=="")
	{
		
	document.getElementById('country').focus();
	alert("Select your COUNTRY");
	return false;
		}
	
	else if(document.getElementById('pwd').value!=document.getElementById('cpwd').value)
		{
		  alert("Please do give same password in both fields");
		  document.getElementById('cpwd').focus();
		  return false;
		
		}
 alert("Welcome");
 return true;

// window.location.assign("index.html");
 
	
}