
   function browse()
   {
	   window.location.assign("UserInterface/browse.html");
   }
   function attendQuiz()
   {
	   window.location.assign("UserInterface/selectQuiz.jsp");
   }
   function check()
   {
	   if(document.getElementById("search").value.length==0)
		   alert("please do enter a word");
   }
  

	    var counter = 0;
     
	 function addTable () {
		 //alert('1');
	        var table = "";
	     //   alert('2');
	        table+="<table><tr id='th1'>            <th >Question</th>                    <td class='col-sm-4'>                <input type='text' name='name"+counter+"' class='form-control' />             </td>             </tr>             <tr>           <th>Options</th>            <td class='col-sm-2'>                A:<input type='text' name='optA"+counter+"'  class='form-control'/>            </td>            <td class='col-sm-2'>                B:<input type='text' name='optB"+counter+"'  class='form-control'/>            </td>            <td class='col-sm-2'>                C:<input type='text' name='optC"+counter+"'  class='form-control'/>            </td>            <td class='col-sm-2'>                d:<input type='text' name='optD"+counter+"'  class='form-control'/>            </td>          </tr>          <tr>           <th>Choose Correct Option</th>            <td class='col-sm-1 selectContainer'>                            <select class='form-control' name='answer"+counter+"'>                                        <option value='A'>A</option>                      <option value='B'>B</option>                      <option value='C'>C</option>                      <option value='D'>D</option>               </select>             </td>            </tr>"
	        	table += '<tr><td><input type="button" class="ibtnDel btn btn-md btn-danger "  value="Delete"></td></tr></table>';
	       
	        var ih=document.getElementById("tables").innerHTML;
	   //     alert(ih);
	        document.getElementById("tables").innerHTML=ih+table;
	   
	        alert(document.getElementById("tables").innerHTML);
	       
	        counter++;
	    }

	 $(document).ready(function () {
		 $("#tables").on("click", ".ibtnDel", function (event) {
	 
	        $(this).closest("table").remove();       
	        counter -= 1;
	    });
 
});