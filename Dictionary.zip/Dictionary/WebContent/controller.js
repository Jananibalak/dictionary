var myApp=angular.module("myApp",[]);
myApp.controller('Hello',["$scope",function($scope)
                          {
	                        $scope.greeting='Hai Janani';
                          }]);