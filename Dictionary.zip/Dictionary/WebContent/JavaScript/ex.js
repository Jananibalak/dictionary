function displayDate()
{
	
	document.getElementById('demo').innerHTML = Date();
}

function onYes()
{
	//alert("in");
	document.getElementById('d1').hidden=false;
	//alert("in");
	//onNo();
}
function onNo()
{
	alert("in")
   var x;
   
   if(confirm( "click ok to register")==true)
	   {
	   
	x="pressed ok";   }
   else
	   {
	   x="pressed cancel";   
	   }
   document.getElementById('n').disabled=true;

}

function onsubmit1()
{
	alert('in');
    if(document.getElementById('name').value=="")
    	{
    	alert('enter name');
    	
    	}
    else if(document.getElementById('email').value=="")
    	{
    	alert('enter email');
    
    	}
    else if(document.getElementById('location').value=="")
	{
	alert('sel location');

	}
   
}