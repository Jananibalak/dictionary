 function loadJSON(){
        	alert("in");
            var data_file = "countries.json";
            var http_request = new XMLHttpRequest();
            try{
               // Opera 8.0+, Firefox, Chrome, Safari
               http_request = new XMLHttpRequest();
            }catch (e){
               // Internet Explorer Browsers
               try{
                  http_request = new ActiveXObject("Msxml2.XMLHTTP");
					
               }catch (e) {
				
                  try{
                     http_request = new ActiveXObject("Microsoft.XMLHTTP");
                  }catch (e){
                     // Something went wrong
                     alert("Your browser broke!");
                     return false;
                  }
					
               }
            }
			
            http_request.onreadystatechange = function(){
			
               if (http_request.readyState == 4  ){
            	   
                  // Javascript function JSON.parse to parse JSON data
                 alert("i");
                 
                  var jsonObj = eval(http_request.responseText);
                 
                  // jsonObj variable now contains the data structure and can
                  // be accessed as jsonObj.name and jsonObj.country.
                 // document.getElementById("Name").innerHTML = jsonObj.name;
                    
                  // document.getElementById("Country").innerHTML = jsonObj.country;
                   
                 for (var i = 0; i < jsonObj.length; i++) {
                	
                	 var object = jsonObj[i];
                	  
                	   
                	 var x = document.createElement("OPTION");
                	
                	    x.setAttribute("value", object["name"]);
                	    var t = document.createTextNode(object["name"]);
                	    x.appendChild(t);
                	    document.getElementById("country").appendChild(x);
    
    // If property names are known beforehand, you can also just do e.g.
    // alert(object.id + ',' + object.Title);
                   }
               }
            }
			
            http_request.open("GET", data_file, true);
            http_request.send();
         }
 
