package  com.atoz.controller;

import io.swagger.annotations.ApiModelProperty;

import java.util.List;

import com.atoz.common.WordBean;

public class Data {



	
	@ApiModelProperty(position = 1, required = true, value = "brief description of the property :output ")
	private List<WordBean> output;
	
	
	public List<WordBean>  getOutput() {
		return output;
	}
	public void setOutput(List<WordBean> outputList) {
		this.output = outputList;
	}
	
	
}
