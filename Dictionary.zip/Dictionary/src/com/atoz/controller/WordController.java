package com.atoz.controller;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

import com.atoz.ErrorCD.Error;
import com.atoz.common.WordBean;
import com.atoz.common.WordDao;

@EnableSwagger2
@RestController
@RequestMapping(value = "/words")

public class WordController {


	@Autowired
	 WordDao uwordDao;
	@Autowired
	MetaData metaData;

	@Autowired
	Data data;
	@Autowired
	Response response;
	private void saveMetaData(boolean success, String description, String responseId){
		
		
		metaData.setSuccess(success);
		metaData.setDescription(description);
		metaData.setResponseId(responseId);
	}
	private void saveResponse(Data data, MetaData metaData, Error errorDet) {
		response.setData(data);
		response.setMetaData(metaData);
		response.setError(errorDet);
	}
	private void saveData(Error erroDet, List testObj) {
		response.setError(erroDet);
			data.setOutput(testObj);
	}
	@ApiOperation(value = "retrieve all records using GET method",notes = "Returns the list of words ",response=Response.class)
	@ApiResponses(value = {      @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping( method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE )
	 public ResponseEntity<Response> getAllWords() {
		ResponseEntity<Response> responseEntity=null;
		Error error= new Error();
		try{
		List<WordBean> wordList= uwordDao.getAllWords();
		if(wordList.isEmpty()){
			
			error.setCode("Error001");
			error.setDescription("Records not found");
			
            saveMetaData(false,"Error Occured","12345");
			
			saveResponse(null,metaData,error);
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
			
		}
		else{
			saveMetaData(true,"Words loaded","Success123");
			saveData(null, wordList);
			saveResponse(data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(response,HttpStatus.OK);
		}	}
		
			catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result Size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else
					error.setDescription(e.getMessage());;
				saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				responseEntity= new  ResponseEntity<Response>(response,HttpStatus.CONFLICT);
				
			}
		
		return responseEntity;
		
		
      }	
	@ApiOperation(value = "retrieve all records of a word",notes = "Returns the detail of a word ",response=Response.class)
	@ApiResponses(value = {     @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request")})
	  @RequestMapping(value = "/{word}" , method = RequestMethod.GET ,produces = MediaType.APPLICATION_JSON_VALUE)
	
	  public ResponseEntity<Response> getWord(@ApiParam(value="WORD to be discribed")@PathVariable("word") String word) {
		 
		  ResponseEntity<Response> responseEntity=null;
		
		Error error= new Error();
		try{
			List<WordBean> wordList = uwordDao.getWord(word);
		if(wordList.isEmpty()){
			System.out.println("inside method");
			error.setCode("Error001");
			error.setDescription("Records not found");
			 saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData,error);
				return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
		}
		else{
			saveMetaData(true,"Words loaded","12345");
			saveData(null, wordList);
			saveResponse(data,metaData, null);
			responseEntity= new  ResponseEntity<Response>(response,HttpStatus.OK);
		}	}
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			error.setCode("00005");
			
			if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
				error.setDescription("Bad Request(Result sise)");
			else if( e instanceof DataAccessException)
				error.setDescription("Database error");
			else
				error.setDescription(e.getMessage());
			saveMetaData(false,"Error Occured","e123");
			
			saveResponse(null,metaData, error);
			System.out.println("Exception****");
			responseEntity= new  ResponseEntity<Response>(response,HttpStatus.CONFLICT);
			
		}
		return responseEntity;
      }	
	@ApiOperation(value = "Save a word using POST method",notes = "Create student data ",response=Response.class)
	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
    @ResponseStatus( value = HttpStatus.CREATED)
	  @RequestMapping( method = RequestMethod.POST ,consumes = MediaType.APPLICATION_JSON_VALUE,produces=MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<Response>  addWord(@RequestBody WordBean wordBean) {
		
		  WordDao wordDao = new WordDao();
		  String word=wordBean.getWord();
		  Error error= new Error();
			try{
			List<WordBean> list=  uwordDao.getWord(word);
			List<WordBean> list1=new ArrayList<WordBean>();
			
			if(list.isEmpty())
			{
		  uwordDao.insertWordJDBC(wordBean);
		  saveMetaData(true,"Word inserted","Success124");
		  list1 = uwordDao.getWord(word);
		  
			saveData(null, list1);
			saveResponse(data,metaData, null);
		  return new  ResponseEntity<Response>(response,HttpStatus.CREATED);
			}
			else
			{
				
				error.setCode("Error002");
				error.setDescription("Word already exist");
				 saveMetaData(false,"Error Occured","e124");
					
					saveResponse(null,metaData,error);
					return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
				
			}
			}
			catch(Exception e){
				e.printStackTrace();			
				error.setCode("00005");
				 if (e instanceof DataAccessException)
				   {
				error.setDescription("Database Error");
				   }
				 else{
					 error.setDescription(e.getMessage());
				 }
				saveMetaData(false,"Error Occured","e124");
				
				saveResponse(null,metaData, error);
				return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
			}	
			
      }	
	@ApiOperation(value = "Delete a word using DELETE method",notes = "Delete a Word",response=Response.class)
	@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping(value = "/{word}" ,method = RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<Response> DeleteWord(@ApiParam(value="WORD to be deleted")@PathVariable("word") String word)
	  {
		Error error= new Error();
		 
		  try{
			  List<WordBean> list1=new ArrayList<WordBean>();
			  list1 = uwordDao.getWord(word);
		  int dResult=uwordDao.deleteWordJDBC(word);
		//  logger.info(dResult);
		  WordBean wb=new WordBean();
		  wb.setWord(word);
			
			
		  if(dResult==0)
			 {
				
					error.setCode("Error003");
					error.setDescription("No such Record");
					 saveMetaData(false,"Error Occured","e125");
						
						saveResponse(null,metaData,error);
						return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
				 
			 }
			 else if(dResult!=-1)
			 {
				 saveMetaData(true,"Word deleted","Success125");
				 
					saveData(null, list1);
					saveResponse(data,metaData, null);
				 return new  ResponseEntity<Response>(response,HttpStatus.OK);
			 }
			 else
			 {
				
					error.setCode("Error005");
					error.setDescription("Not deleted");
					 saveMetaData(false,"Error Occured","e125");
						
						saveResponse(null,metaData,error);
					return new  ResponseEntity<Response>(response,HttpStatus.NOT_MODIFIED);
			 }
		  }
		  catch(Exception e){
			  e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else{
					System.out.println("$$");
					error.setDescription(e.getMessage());
				}
					saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				System.out.println("Exception****"+e.getCause());
				return new  ResponseEntity<Response>(response,HttpStatus.CONFLICT);
			}	
    	
      }	
	  @ApiOperation(value = "Update meaning of a word using PUT method",notes = "Update Meaning",response=Response.class)
		@ApiResponses(value = {       @ApiResponse(code = 404, message = "Invalid Information Sent"),    @ApiResponse(code = 500, message = "Internal Server Error"), @ApiResponse(code = 400, message = "Bad Request") })
	  @RequestMapping(value="/{wid}",method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_JSON_VALUE )
	 @ResponseStatus(value=HttpStatus.CREATED)
	  public ResponseEntity<Response> UpdateMeaning(@ApiParam(value="id of word")@PathVariable("wid") int wid,@RequestBody WordBean wordBean)
	  {
		  System.out.println("in put");
		 
		 
		 Error error= new Error();
		 try{
			 if(wordBean==null)
				 System.out.println("kjhlkjh,");
			 String wordUpdate=wordBean.getWord();
			 String meaningUpdate=wordBean.getMeaning();
			 int id=wid;
			 
			 wordBean.setId(wid);
		 int r=uwordDao.updateMeaning(id,wordUpdate,meaningUpdate);
		 if(r==0)
		 {
			 System.out.println("No such Record");
			 
			 error.setCode("Error003");
				error.setDescription("No such Record");
				 saveMetaData(false,"Error Occured","e125");
					
					saveResponse(null,metaData,error);
					return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
			 
		 }
		 else if(r!=-1){
			 System.out.println("updated");
			 List<WordBean> list1=new ArrayList<WordBean>();
			 saveMetaData(true,"Word updated","12345");
			 list1 = uwordDao.getWord(wordBean.getWord());
			 saveData(null, list1);
				saveResponse(data,metaData, null);
			 return new  ResponseEntity<Response>(response,HttpStatus.OK);
			
		 }
		 else
		 {
			 System.out.println("Error004");
			
			/*	error.setCode("Error004");
				error.setDescription("Not Updated");
				 saveMetaData(false,"Error Occured","12345");
					
					saveResponse(null,metaData,error);
					System.out.println(response.getError().getDescription());
				return new  ResponseEntity<Response>(response,HttpStatus.NOT_MODIFIED);*/

				error.setCode("Error004");
				error.setDescription("Not updated");
				 saveMetaData(false,"Error Occured","e126");
					
					saveResponse(null,metaData,error);
					return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND) ;
		 }
		 }
		 catch(Exception e){
			 e.printStackTrace();
				error.setCode("00005");
				
				if( e instanceof IncorrectResultSizeDataAccessException  || e instanceof EmptyResultDataAccessException)
					error.setDescription("Bad Request(Result size)");
				else if( e instanceof DataAccessException)
					error.setDescription("Database error");
				else{
					System.out.println("$$");
					error.setDescription(e.getMessage());
				}
					saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
				System.out.println("Exception****"+e.getCause());
				return new  ResponseEntity<Response>(response,HttpStatus.CONFLICT);
			}	
    	
      }	
	 /* @RequestMapping(value = "/Update_Type" , method = RequestMethod.PUT )
	  public String UpadateType(@RequestBody WordBean wordBean)
	  {
		  
		 
		 String wordUpdate=wordBean.getWord();
		 String typeUpdate=wordBean.getType();
		 int id=wordBean.getId();
		// logger.info(wordUpdate+typeUpdate);
		 int r= uwordDao.updateType(id,wordUpdate,typeUpdate);
		 if(r!=-1)
			 return r+" rows affected..";
		 else
			 return "Not updated";	
				
    	
      }	
	  @RequestMapping(value = "/Update_Frequency" , method = RequestMethod.PUT )
	  public String UpadateFrequency(@RequestBody WordBean wordBean)
	  {
		
		 String wordUpdate=wordBean.getWord();
		 int id=wordBean.getId();
		 int FreqUpdate=wordBean.getFrequency();
		 //logger.info(wordUpdate+FreqUpdate);
		 int r= uwordDao.updateFrequency(id,wordUpdate,FreqUpdate);
		 if(r!=-1)
			 return r+" rows affected..";
		 else
			 return "Not updated";
    	
      }	
	  @RequestMapping(value = "/getWord" , method = RequestMethod.POST )
	  public String getWord(@RequestBody WordBean wordBean)
	  {
		
		 int id=wordBean.getId();
		 
		
				String s=  uwordDao.getWord(id);
				String json=new Gson().toJson(s);
				return json;
    	
      }	
	  @RequestMapping(value = "/getWords" , method = RequestMethod.POST )
	  public String getWords(@RequestBody WordBean wordBean)
	  {
		
		 String word=wordBean.getWord();
		 
		
				List<WordBean> list=  uwordDao.getWord(word);
				String json=new Gson().toJson(list);
				return json;
    	
      }	*/
	
		  @RequestMapping(method = RequestMethod.PUT ,produces = MediaType.APPLICATION_JSON_VALUE )
	 
	  public @ResponseBody ResponseEntity<Response> UpdateMeaning2()
	  {
		   Error error = new Error();
           error.setCode("er006");
       	error.setDescription("Check the url and request method");
           saveMetaData(false,"Error Occured","e123");
			
			saveResponse(null,metaData, error);
           ResponseEntity<Response> responseEntity = new ResponseEntity<Response>(
           response, HttpStatus.BAD_REQUEST);
       	System.out.println(response.getError().getDescription());
           return responseEntity;
		
				
				
				
			
    	
      }	

	  @RequestMapping(method = {RequestMethod.DELETE},produces = MediaType.APPLICATION_JSON_VALUE )
		
	  public @ResponseBody ResponseEntity<Response> UpdateMeaning3()
	  {

		   Error error = new Error();
          error.setCode("er006");
      	error.setDescription("Check the url and request method");
          saveMetaData(false,"Error Occured","e123");
			
			saveResponse(null,metaData, error);
          ResponseEntity<Response> responseEntity = new ResponseEntity<Response>(
          response, HttpStatus.BAD_REQUEST);
      	System.out.println(response.getError().getDescription());
          return responseEntity;
		

			
    	
      }	

	
	  @ExceptionHandler(TypeMismatchException.class)
	    public @ResponseBody ResponseEntity<Object> typeMismatchExceptionHandler(TypeMismatchException exception, HttpServletRequest request) {
	           Error error = new Error();
	           error.setCode("er006");
	           error.setDescription("Word Id must be a number.");
	           saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
	           ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
	           response, HttpStatus.BAD_REQUEST);
	           return responseEntity;
	    }
	  
	    @ExceptionHandler(Exception.class)
	    public @ResponseBody ResponseEntity<Object> generalExceptionHandler(Exception exception, HttpServletRequest request) {
	    	Error error = new Error();
	           error.setCode("er006");
	           error.setDescription("Bad request..check the url and request method");
	           saveMetaData(false,"Error Occured","e123");
				
				saveResponse(null,metaData, error);
	           ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(
	           response, HttpStatus.BAD_REQUEST);
	           return responseEntity;
	    }
	   /* @ExceptionHandler(AccessDeniedException.class)
	    public @ResponseBody ResponseEntity<Object> exceptionHandler(Exception exception, HttpServletRequest request) {
	    	//System.out.println("inga varala");
	           Error error = new Error();
	           error.setCode("TRA1004");
	           error.setDescription("Bad Request");
	           ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(error, HttpStatus.BAD_REQUEST);
	           return responseEntity;
	    }*/
	
	
 
    
}
