package com.atoz.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.atoz.common.QuizContentBean;
import com.atoz.common.QuizContentDao;
import com.atoz.common.QuizDao;

/**
 * Servlet implementation class SelectQuiz
 */
@WebServlet("/SelectQuiz")
public class SelectQuiz extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectQuiz() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession httpSession=request.getSession(true);
		String emailId=(String) httpSession.getAttribute("emailId");
		Cookie c[]=request.getCookies();
		if(c!=null)
		{
		for(int i=0;i<c.length;i++)
		{
			if(c[i].getName().equals("emailId"))
				emailId=c[i].getValue();
				
		}
		}
		System.out.println("sq"+emailId);
		if(emailId!=null)
		{
			System.out.println(request.getRequestURI());

		out.println("<!DOCTYPE html><html><head><meta charset='ISO-8859-1'>  <link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'><script>function w3_open() {    document.getElementById('mySidebar').style.display = 'block';    document.getElementById('myOverlay').style.display = 'block';}function w3_close() {    document.getElementById('mySidebar').style.display = 'none';    document.getElementById('myOverlay').style.display = 'none';}</script>  <style>#llist{        "
				+ "         position:absolute;     "
				+ "         right:10px;             "
				+ "          top:10px;                         "
				+ "   }  body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }.fcenter{  float:center; }#formCentre{  position: absolute;    left: 500px;    top: 150px;     width:500px;  height:500px;}</style>  <link rel='shortcut icon' href='images/ticon.ico' />  <meta charset='utf-8'>  <meta name='viewport' content='width=device-width, initial-scale=1'>  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>  <link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'><script>function w3_open() {    document.getElementById('mySidebar').style.display = 'block';    document.getElementById('myOverlay').style.display = 'block';}function w3_close() {    document.getElementById('mySidebar').style.display = 'none';    document.getElementById('myOverlay').style.display = 'none';}</script>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>  <link rel='shortcut icon' href='UserInterface/images/ticon.ico' /> <script>  function onFinish(){	var qid=document.getElementById('quizId').value;	    if(qid=='')	{	document.getElementById('quizId').focus();		alert('select Quiz ID');	return false;	}		return true;		}  </script><title>Select Quiz</title></head><body ><div class='w3-sidebar w3-bar-block w3-animate-left' style='display:none;z-index:5' id='mySidebar'>  <button style='background-color:orange' class='w3-bar-item w3-button w3-large' onclick='w3_close()'>Close &times;</button>      <a style='background-color:#337ab7'href='/Dictionary/SearchedWords.jsp' class='w3-bar-item w3-button'>My Search History</a>   <a style='background-color:#337ab7' href='/Dictionary/SelectQuiz' class='w3-bar-item w3-button'>Attend Quiz</a>    <a style='background-color:#337ab7' href='/Dictionary/UQuizReport.jsp' class='w3-bar-item w3-button'>My Report</a>     <a style='background-color:#337ab7' href='/Dictionary/UserInterface/browse.html' class='w3-bar-item w3-button'>Browse</a>      <a style='background-color:#337ab7' href='/Dictionary/TotalScore.jsp' class='w3-bar-item w3-button'>My Total Score</a>       <a style='background-color:#337ab7' href='/Dictionary/Subscribe.jsp' class='w3-bar-item w3-button'>Mail my report</a>        <a style='background-color:#337ab7'  href='/Dictionary/LeaderBoard.jsp' class='w3-bar-item w3-button'>My Rank</a>         <a style='background-color:#337ab7'  href='/Dictionary/RecentScore.jsp' class='w3-bar-item w3-button'>My Recent Score</a> <a style='background-color:#337ab7'  href='/Dictionary/IndexPage?ls=1' class='w3-bar-item w3-button'>Go Home</a></div><div class='w3-overlay w3-animate-opacity' onclick='w3_close()' style='cursor:pointer' id='myOverlay'></div><div>  <button class='w3-button w3-white w3-xxlarge' onclick='w3_open()'>&#9776;</button><div id='llist'>"
				+ " <a style='color:red;font-family:'Comic Sans MS';font-size:20px' >"+emailId+"</a> <a href='/Dictionary/Login?lg=3'>Logout</a>"
						
						+ "</div><div class='fcenter' style='color:white;font-family:'Comic Sans MS''><fieldset id='formCentre' ><legend class='panel-heading' style='color:white;font-family:'Comic Sans MS''>Select QuizId</legend><form method='get' class='panel-body' target='_blank' action='/Dictionary/UserQContent.jsp'><input type='hidden' name='in' value='1'/><div class='form-group'>  <label for='quizId'>Id:</label>  <select class='form-control' id='quizId' name='quizId'  >    ");
		QuizDao qd=new QuizDao();
		List<String> list=qd.listQuiz();
		HttpSession session=request.getSession();
		QuizContentDao qcDao=new QuizContentDao();

		List<QuizContentBean> qcbList=qcDao.retrieveContent((String)session.getAttribute("quizId"));
		QuizContentBean[] QCBArray=qcbList.toArray(new QuizContentBean[qcbList.size()]);
		int noq=qcbList.size();
		int score=0;
		for(int i=0;i<noq;i++)
		{
			session.removeAttribute("q"+i);
			
		}
		session.removeAttribute("quizId");
		session.removeAttribute("ques");
		//System.out.println("Available QuizId");
		//int l=0;
		for(String qi:list)
		{
			out.print("<option value='"+qi+"'>"+qi+"</option>");
		}
		
		out.print(" </select></div><div class='form-group'><button type='submit' onclick='return onFinish()'  class='btn btn-primary btn-block'>START</button></div></form></fieldset></div></div></body></html>");
	
		
		}
		else
		{
			response.sendRedirect("/Dictionary/UserInterface/Login.html");
		}
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
