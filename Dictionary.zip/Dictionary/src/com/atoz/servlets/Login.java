package com.atoz.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String lg=request.getParameter("lg");
		System.out.println(lg+"");
		if(lg.equals("3"))
		{
			HttpSession httpSession=request.getSession(true);
			httpSession.invalidate();
			
			Cookie ck=new Cookie("emailId","");
			ck.setMaxAge(0);
			response.addCookie(ck);
			
			out.println("<!DOCTYPE html><html><head><meta charset='ISO-8859-1'><style>body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }.fcenter{  float:center; }#formCentre{  position: absolute;    left: 500px;    top: 150px;     width:500px;  height:500px;}</style>  <link rel='shortcut icon' href='images/ticon.ico' />  <meta charset='utf-8'>  <meta name='viewport' content='width=device-width, initial-scale=1'>  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>   <script>  function onFinish(){	var password=document.getElementById('pwd').value;	var ppattern1='[0-9]';	var ppattern2='[a-zA-z]';		if(document.getElementById('email').value=='')	{	document.getElementById('email').focus();	alert('enter EmailId');	return false;	}	else if(password=='')	{	document.getElementById('pwd').focus();		alert('enter password');	return false;	}		return true;		}  </script><title>Login</title></head><body ><div class='fcenter' style='color:white;font-family:'Comic Sans MS''><fieldset id='formCentre' ><legend class='panel-heading' style='color:white;font-family:'Comic Sans MS''>Login</legend><form class='panel-body'   method='post' action='/Dictionary/IndexPage'><div class='form-group'>  <label for='email'>EmailId:</label>  <input name='email' type='email' class='form-control' id='email'></div><div class='form-group'>  <label for='pwd'>Password:</label>  <input type='password' class='form-control' id='pwd'  name='pwd'></div><p style='color:'red''>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logged out..Login again to continue</p><input type='hidden' name='ls' value='1'/> <div class='form-group'><button type='submit' onclick='return onFinish()'  class='btn btn-primary btn-block'>Login</button></div></form></fieldset></div></body></html>");
		    
		}
		else
		{
		out.println("<!DOCTYPE html><html><head><meta charset='ISO-8859-1'><style>body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }.fcenter{  float:center; }#formCentre{  position: absolute;    left: 500px;    top: 150px;     width:500px;  height:500px;}</style>  <link rel='shortcut icon' href='images/ticon.ico' />  <meta charset='utf-8'>  <meta name='viewport' content='width=device-width, initial-scale=1'>  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>   <script>  function onFinish(){	var password=document.getElementById('pwd').value;	var ppattern1='[0-9]';	var ppattern2='[a-zA-z]';		if(document.getElementById('email').value=='')	{	document.getElementById('email').focus();	alert('enter EmailId');	return false;	}	else if(password=='')	{	document.getElementById('pwd').focus();		alert('enter password');	return false;	}		return true;		}  </script><title>Login</title></head><body ><div class='fcenter' style='color:white;font-family:'Comic Sans MS''><fieldset id='formCentre' ><legend class='panel-heading' style='color:white;font-family:'Comic Sans MS''>Login</legend><form class='panel-body'   method='post' action='/Dictionary/IndexPage'><div class='form-group'>  <label for='email'>EmailId:</label>  <input name='email' type='email' class='form-control' id='email'></div><div class='form-group'>  <label for='pwd'>Password:</label>  <input type='password' class='form-control' id='pwd'  name='pwd'></div><p style='color:'red''>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Invalid details</p><input type='hidden' name='ls' value='1'/> <div class='form-group'><button type='submit' onclick='return onFinish()'  class='btn btn-primary btn-block'>Login</button></div></form></fieldset></div></body></html>");
	    }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
