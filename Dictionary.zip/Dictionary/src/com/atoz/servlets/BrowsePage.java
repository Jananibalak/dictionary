package com.atoz.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.atoz.common.FrequencyComparator;
import com.atoz.common.WordBean;
import com.atoz.common.WordDao;

/**
 * Servlet implementation class BrowsePage
 */
@WebServlet("/BrowsePage")
public class BrowsePage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BrowsePage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				response.setContentType("text/html");
				PrintWriter out=response.getWriter();
				HttpSession httpSession=request.getSession(true);
				String emailId=(String) httpSession.getAttribute("emailId");
				Cookie c[]=request.getCookies();
				if(c!=null)
				{
				for(int i=0;i<c.length;i++)
				{
					if(c[i].getName().equals("emailId"))
						emailId=c[i].getValue();
						
				}
				}
				System.out.println(emailId);
				if(emailId!=null)
				{
			      char charSearch=request.getParameter("letter").charAt(0);
			     
						WordDao wordDao1=new WordDao();
			            List<WordBean> wordList1= wordDao1.getWords(charSearch);
						
						
						
		 out.print("<!DOCTYPE html><html><head><link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script><meta charset='ISO-8859-1'>  <link rel='shortcut icon' href='images/ticon.ico' /><title>Browse </title>  <link rel='stylesheet' href='https://www.w3schools.com/w3css/4/w3.css'><script>function w3_open() {    document.getElementById('mySidebar').style.display = 'block';    document.getElementById('myOverlay').style.display = 'block';}function w3_close() {    document.getElementById('mySidebar').style.display = 'none';    document.getElementById('myOverlay').style.display = 'none';}</script><style>#llist{        "
				+ "         position:absolute;     "
				+ "         right:10px;             "
				+ "          top:10px;                         "
				+ "   }  body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }</style><script type='text/javascript'>	");
		 
							out.println("function reply_click(clicked_id){		var str=document.getElementById(clicked_id).innerText;	document.getElementById('letter').value=str;		  	  	}var form = document.getElementById('form-id');document.getElementsByTagName('button').addEventListener('click', function () {  form.submit();});</script></head><body><div class='w3-sidebar w3-bar-block w3-animate-left' style='display:none;z-index:5' id='mySidebar'>  <button class='btn btn-primary letter-button' style='background-color:orange' class='w3-bar-item w3-button class='btn btn-primary letter-button' w3-large' onclick='w3_close()'>Close &times;</button class='btn btn-primary letter-button'>      <a style='background-color:#337ab7'href='/Dictionary/SearchedWords.jsp' class='w3-bar-item w3-button class='btn btn-primary letter-button''>My Search History</a>   <a style='background-color:#337ab7' href='/Dictionary/SelectQuiz' class='w3-bar-item w3-button class='btn btn-primary letter-button''>Attend Quiz</a>    <a style='background-color:#337ab7' href='/Dictionary/UQuizReport.jsp' class='w3-bar-item w3-button class='btn btn-primary letter-button''>My Report</a>     <a style='background-color:#337ab7' href='/Dictionary/UserInterface/browse.html' class='w3-bar-item w3-button class='btn btn-primary letter-button''>Browse</a>      <a style='background-color:#337ab7' href='/Dictionary/TotalScore.jsp' class='w3-bar-item w3-button class='btn btn-primary letter-button''>My Total Score</a>       <a style='background-color:#337ab7' href='/Dictionary/Subscribe.jsp' class='w3-bar-item w3-button class='btn btn-primary letter-button''>Mail my report</a>        <a style='background-color:#337ab7'  href='/Dictionary/LeaderBoard.jsp' class='w3-bar-item w3-button class='btn btn-primary letter-button''>My Rank</a>         <a style='background-color:#337ab7'  href='/Dictionary/RecentScore.jsp' class='w3-bar-item w3-button class='btn btn-primary letter-button''>My Recent Score</a> <a style='background-color:#337ab7'  href='/Dictionary/IndexPage?ls=1' class='w3-bar-item w3-button class='btn btn-primary letter-button''>Go Home</a></div><div class='w3-overlay w3-animate-opacity' onclick='w3_close()' style='cursor:pointer' id='myOverlay'></div><div>  <button class='btn btn-primary letter-button' class='w3-button class='btn btn-primary letter-button' w3-white w3-xxlarge' onclick='w3_open()'>&#9776;</button class='btn btn-primary letter-button'><div id='llist'>"
				+ " <a style='color:red;font-family:'Comic Sans MS';font-size:20px' >"+emailId+"</a> <a href='/Dictionary/Login?lg=3'>Logout</a>"
						
						+ "</div><h1>Browse Words...</h1><p id='txtHint'></p><div class='container'>  <div class='btn-toolbar'>    <div class='btn-group btn-group-sm'>     <form action='/Dictionary/BrowsePage' id='form-id'>      <button class='btn btn-primary letter-button' class='btn btn-primary letter-button class='btn btn-primary letter-button'' id='b1'  onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>A</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b2' onclick=reply_click(this.id) style='width:60px' class='btn btn-default'>B</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b3'  onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>C</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b4'  onclick=reply_click(this.id) style='width:60px' class='btn btn-default'>D</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b5'  onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>E</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b6'  onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>F</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b7' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>G</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b8'  onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>H</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b9'  onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>I</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b10' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>J</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b11' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>K</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b12' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>L</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b13' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>M</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b14' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>N</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b5' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>O</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b16' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>P</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b17' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>Q</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b18' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>R</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b19' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>S</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b20' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>T</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b21' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>U</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b22' onclick=reply_click(this.id)  style='width:60px'class='btn btn-default'>V</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b23' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>W</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b24' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>X</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b25' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>Y</button class='btn btn-primary letter-button'>      <button class='btn btn-primary letter-button' id='b26' onclick=reply_click(this.id) style='width:60px'class='btn btn-default'>Z</button class='btn btn-primary letter-button'>             <input type='hidden' id='letter' name='letter'/>      </form>    </div>  </div></div><p id='p1' style='color:white'>");
							if(wordList1!=null)						{
								 Collections.sort(wordList1,new FrequencyComparator());
													Iterator<WordBean> itr =  wordList1.iterator();
													while(itr.hasNext()){	
														WordBean wordBean = itr.next();
														
														//out.println("var anchor = document.createElement('a');var t = document.createTextNode('"+wordBean.getWord()+"'); anchor.appendChild(t); document.body.appendChild(anchor);");
														out.println("<a style='color:grey;' href='/Dictionary/SearchMeaning.jsp?search="+wordBean.getWord()+"'>"+wordBean.getWord()+"</a>");
													}
													out.print("</p></div></body></html>");
							}
				}
				else
				{
					response.sendRedirect("/Dictionary/UserInterface/Login.html");
				}
									          
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
	}

}
