package com.atoz.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.atoz.common.SubUserDao;
import com.atoz.common.UserBean;
import com.atoz.common.UserDao;
import com.atoz.common.WordBean;
import com.atoz.common.WordDao;
import com.atoz.controller.WordController;


/**
 * Servlet implementation class IndexPage
 */
@WebServlet("/IndexPage")
public class IndexPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ServletConfig config;
	Connection con;
	 final static Logger logger=Logger.getLogger(IndexPage.class);
    /**
     * Default constructor. 
     */
    public IndexPage() {
        // TODO Auto-generated constructor stub
    }
    public void init(ServletConfig config)
    {
    	this.config = config;
    	
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//out.print("<html><body>HI</body></html>");
		int ls=Integer.parseInt(request.getParameter("ls"));
		if(ls==1){
			HttpSession httpS=request.getSession(true);
			
		String eid=request.getParameter("email");
		String pwd=request.getParameter("pwd");
		
		UserDao ud=new UserDao();
		logger.info(eid+" "+pwd);
		//con = DaoHelper.getConnection();
		
		int s=ud.login(eid, pwd);
	
			
		//System.out.println(emailId);
		if(s==1  )
		{		
			System.out.println("*innnn*");
		HttpSession httpSession=request.getSession(true);
		httpSession.setAttribute("emailId", eid);
		
		out.print("<!DOCTYPE html> <html lang='en'>     "
				+ "<head>         "
				+ "<meta charset='utf-8'> "
				+ "        <meta http-equiv='X-UA-Compatible' content='IE=edge'>"
				+ "         <meta name='viewport' content='width=device-width, initial-scale=1'>         "
				+ "<meta name='description' content=''>  "
				+ "       <meta name='author' content=''>       "
				+ "  <link rel='shortcut icon' href='/Dictionary/UserInterface/images/ticon.ico' />     "
				+ "    <style>             "
				+ " #llist{        "
				+ "         position:absolute;     "
				+ "         right:10px;             "
				+ "          top:10px;                         "
				+ "   }             "
				+ " body{              font-family:'Comic Sans MS';} ul { list-style-type: none; padding: 0;   width: 200px; border: 1px solid red; display: none;}ul li a {display: block;} "
				+ "       </style>          "
				+ "<script src='/Dictionary/UserInterface/js/index.js'></script> <script src='/Dictionary/UserInterface/js/jquery-2.1.1.min.js'></script>  "
				+ "       <title>~ A ~ TO ~ Z ~ </title>         "
				+ "<link href='https://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>    "
				+ "     <!-- Bootstrap Core CSS -->       "
				
				
         		+ "  <link href='/Dictionary/UserInterface/bootstrap/css/bootstrap.min.css' rel='stylesheet'>  "
				+ "       <!-- Font Awesome CSS -->        "
				+ " <link href='/Dictionary/UserInterface/css/font-awesome.min.css' rel='stylesheet'> 	"
				+ "	 		<!-- Custom CSS -->        "
				+ " <link href='/Dictionary/UserInterface/css/animate.css' rel='stylesheet'>     "
				+ "    <!-- Custom CSS -->        "
				+ " <link href='/Dictionary/UserInterface/css/style.css' rel='stylesheet'>   "
				+ "      <!-- Custom Fonts -->        "
				+ " <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>                 <!--[if lt IE 9]>          "
				+ "   <script src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js'></script> "
				+ "    <script src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js'></script>"
				+ "         <![endif]-->     </head>      "
				+ "    <body>                 "
				+ " <!-- Start Logo Section -->         "
				+ "<section id='logo-section' class='text-center'>        "
				+ "     <div class='container'>               "
				+ "  <div class='row'>                     "
				+ "<div class='col-md-12'>                         "
				+ "<div class='logo text-center'>                             "
				+ "<h1>~ A ~ TO ~ Z ~</h1>                             "
				+ "<span>Dictionary</span>                         "
				+ "</div>                     "
				+ "</div>                                     "
				+ "</div>            "
				+ " </div>        "
				+ " </section>         "
				+ "<!-- End Logo Section -->        "
				+ " <div id='llist'>"
				+ " <a style='color:red;font-family:'Comic Sans MS';font-size:20px' >"+eid+"</a> <a href='/Dictionary/Login?lg=3'>Logout</a>");
						if(eid.equals("jananibala2512@gmail.com")){
							System.out.print("inside admin"+eid);
						out.println( "&nbsp;&nbsp;<a href='/Dictionary/UserInterface/insertQuiz.html'>Insert Quiz</a>");
						out.println( "&nbsp;&nbsp;<a href='/Dictionary/InsertWord.jsp'>Insert Word</a>");
						out.println( "&nbsp;&nbsp;<a href='/Dictionary/UpdateWord.html'>Update Word</a>");
						}
						else
						{
							logger.info("not inside admin"+eid);
						}
						out.println("</div><!-- Start Main Body Section -->         <div class='mainbody-section text-center'>             <div class='container'>                 <div class='row'>                                          <div class='col-md-3'>                                                  <div class='menu-item'>                             <a  href='/Dictionary/SearchedWords.jsp'data-toggle='modal'>                                 <i class='glyphicon glyphicon-search'></i>                                "
						+ " <p>My Search History</p>   "
						+ "  </a>"
						+ " </div>"
						+ "                                                  <div class='menu-item'> "
						+ "                            <a  href='/Dictionary/SelectQuiz' data-toggle='modal'>"
						+ "                                 <i class='glyphicon glyphicon-list-alt'></i>"
						+ "                                 <p  >Attend Quiz</p>"
						+ "                             </a>"
						+ "                         </div> "
						+ "                                                 <div class='menu-item'>"
						+ "                             <a href='/Dictionary/UQuizReport.jsp' data-toggle='modal'>   "
						+ "                              <i class='material-icons'>insert_chart</i>                                 <p>My report</p>                             </a>                         </div>        "
						+"                                           <div class='menu-item'> 						                           <a  href='Hangman.jsp' data-toggle='modal'>						                                 <i class='fa fa-gamepad' aria-hidden='true'></i>						                                <p  >Play</p>						                            </a>						                        </div> "
						+"</div>                                          <div class='col-md-6'>                                                  <!-- Start Carousel Section -->                                                                                 <br> <br>                            <br> <br>                                 <!-- Wrapper for slides -->                                 <div class='carousel-inner'>                                     <div class='item active'>                              <form action='/Dictionary/SearchMeaning.jsp'><input list='search1' class='form-control' name='search'>  <datalist id='search1' > ");
								WordDao wd=new WordDao();
								List<WordBean> wb=wd.getWords();
								for(WordBean w:wb)
				                out.println("   <option value='"+w.getWord()+"'>");
								out.println(" </datalist> <input type='submit' class='form-control'  onclick='check()' value='Search'/>    </form>                                 </div>                                                                      </div>                             <br> <br> <br> <br>    <br> <br>                                                     <!-- Start Carousel Section -->                                                  <div class='row'>                             <div class='col-md-6'>                                 <div class='menu-item ' >                                     <a href='/Dictionary/UserInterface/browse.html' data-toggle='modal'>                                        <i class='material-icons'>live_help</i>                                         <p >Browse</p>                                     </a>                                 </div>                             </div>                                                          <div class='col-md-6'>                                 <div class='menu-item'>                                     <a href='/Dictionary/TotalScore.jsp' data-toggle='modal'>                                         <i class='glyphicon glyphicon-star'></i>                                         <p>My Total Score</p>                                     </a>                                 </div>                             </div>                                                      </div>                                              </div>                                          <div class='col-md-3'>                                                  <div class='menu-item'>                             <a href='/Dictionary/Subscribe.jsp' data-toggle='modal'>                                 <i class='fa fa-envelope-o'></i>                                 <p>Mail my Report</p>                             </a>                         </div>                                                  <div class='menu-item '>                             <a href='/Dictionary/LeaderBoard.jsp' data-toggle='modal'>                                 <i class='fa fa-mortar-board'></i>                                 <p>My Rank</p>                             </a>                         </div>                                                  <div class='menu-item'>                             <a href='/Dictionary/RecentScore.jsp' data-toggle='modal'>                                 <i class='glyphicon glyphicon-star-empty'></i>                                 <p>My Recent Score</p>                             </a>                         </div>    ");
								if(new SubUserDao().checkUser(eid))
								{
									out.print("                                           <div class='menu-item'> 						                           <a  href='unsubscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >UnSubscribe</p>						                            </a>						                        </div> ");
									}
								else
								out.print("                                           <div class='menu-item'> 						                           <a  href='daily_subscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >Subscribe</p>						                            </a>						                        </div> ");
								out.print("</div>                 </div>             </div>         </div>         <!-- End Main Body Section -->     ");
								 //out.println("<a href='Hangman.jsp'>Play</a> <i class='fa fa-gamepad' aria-hidden='true'></i>  ");
								out.print("</body>      </html>");
	    }
		else
		{
			
	    // out.print("invalid Credentials!");  
       // RequestDispatcher rd=request.getRequestDispatcher("/UserInterface/Login.html");  
       // rd.include(request, response);  
			
			out.println("<!DOCTYPE html><html><head><meta charset='ISO-8859-1'><style>body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }.fcenter{  float:center; }#formCentre{  position: absolute;    left: 500px;    top: 150px;     width:500px;  height:500px;}</style>  <link rel='shortcut icon' href='images/ticon.ico' />  <meta charset='utf-8'>  <meta name='viewport' content='width=device-width, initial-scale=1'>  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>   <script>  function onFinish(){	var password=document.getElementById('pwd').value;	var ppattern1='[0-9]';	var ppattern2='[a-zA-z]';		if(document.getElementById('email').value=='')	{	document.getElementById('email').focus();	alert('enter EmailId');	return false;	}	else if(password=='')	{	document.getElementById('pwd').focus();		alert('enter password');	return false;	}		return true;		}  </script><title>Login</title></head><body ><div class='fcenter' style='color:white;font-family:'Comic Sans MS''><fieldset id='formCentre' ><legend class='panel-heading' style='color:white;font-family:'Comic Sans MS''>Login</legend><form class='panel-body'   method='post' action='/Dictionary/IndexPage'><div class='form-group'>  <label for='email'>EmailId:</label>  <input name='email' type='email' class='form-control' id='email'></div><div class='form-group'>  <label for='pwd'>Password:</label>  <input type='password' class='form-control' id='pwd'  name='pwd'></div><input type='hidden' name='ls' value='1'/> <p style='color:'red''>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Invalid details</p><div class='form-group'><button type='submit' onclick='return onFinish()'  class='btn btn-primary btn-block'>Login</button></div></form></fieldset></div><p>#Invalid Details</p></body></html>");
			
		}
		}
		else if(ls==2)
		{
			String name=request.getParameter("name");
			String eid=request.getParameter("email");
			String pwd=request.getParameter("pwd");
			String country=request.getParameter("country");
			
			UserBean uBean=new UserBean();
		    UserDao userDao=new UserDao();
			uBean.setEmailId(eid);
			uBean.setPassword(pwd);
			uBean.setName(name);
			uBean.setCountry(country);
			
			int res=userDao.signUp(uBean);
			if(res==1){
				Cookie cookies=new Cookie("emailId",eid);
				response.addCookie(cookies);
				
				out.print("<!DOCTYPE html> <html lang='en'>     "
						+ "<head>         "
						+ "<meta charset='utf-8'> "
						+ "        <meta http-equiv='X-UA-Compatible' content='IE=edge'>"
						+ "         <meta name='viewport' content='width=device-width, initial-scale=1'>         "
						+ "<meta name='description' content=''>  "
						+ "       <meta name='author' content=''>       "
						+ "  <link rel='shortcut icon' href='/Dictionary/UserInterface/images/ticon.ico' />     "
						+ "    <style>             "
						+ " #llist{        "
						+ "         position:absolute;     "
						+ "         right:10px;             "
						+ "          top:10px;                         "
						+ "   }             "
						+ " body{              font-family:'Comic Sans MS';}  "
						+ "       </style>          "
						+ "<script src='/Dictionary/UserInterface/js/index.js'></script> <script src='/Dictionary/UserInterface/js/jquery-2.1.1.min.js'></script>  "
						+ "       <title>~ A ~ TO ~ Z ~ </title>         "
						+ "<link href='https://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>    "
						+ "     <!-- Bootstrap Core CSS -->       "
						
						
		         		+ "  <link href='/Dictionary/UserInterface/bootstrap/css/bootstrap.min.css' rel='stylesheet'>  "
						+ "       <!-- Font Awesome CSS -->        "
						+ " <link href='/Dictionary/UserInterface/css/font-awesome.min.css' rel='stylesheet'> 	"
						+ "	 		<!-- Custom CSS -->        "
						+ " <link href='/Dictionary/UserInterface/css/animate.css' rel='stylesheet'>     "
						+ "    <!-- Custom CSS -->        "
						+ " <link href='/Dictionary/UserInterface/css/style.css' rel='stylesheet'>   "
						+ "      <!-- Custom Fonts -->        "
						+ " <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>                 <!--[if lt IE 9]>          "
						+ "   <script src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js'></script> "
						+ "    <script src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js'></script>"
						+ "         <![endif]-->     </head>      "
						+ "    <body>                 "
						+ " <!-- Start Logo Section -->         "
						+ "<section id='logo-section' class='text-center'>        "
						+ "     <div class='container'>               "
						+ "  <div class='row'>                     "
						+ "<div class='col-md-12'>                         "
						+ "<div class='logo text-center'>                             "
						+ "<h1>~ A ~ TO ~ Z ~</h1>                             "
						+ "<span>Dictionary</span>                         "
						+ "</div>                     "
						+ "</div>                                     "
						+ "</div>            "
						+ " </div>        "
						+ " </section>         "
						+ "<!-- End Logo Section -->        "
						+  " <div id='llist'>"
				+ " <a style='color:red;font-family:'Comic Sans MS';font-size:20px' >"+eid+"</a> <a href='/Dictionary/Login?lg=3'>Logout</a>");
				if(eid=="jananibala2512@gmail.com"){
					out.println( "&nbsp;&nbsp;<a href='/Dictionary/UserInterface/insertQuiz.html'>Insert Quiz</a>");
					out.println( "&nbsp;&nbsp;<a href='/Dictionary/InsertWord.jsp'>Insert Word</a>");
					}
					
						
						out.print("</div><!-- Start Main Body Section -->         <div class='mainbody-section text-center'>             <div class='container'>                 <div class='row'>                                          <div class='col-md-3'>                                                  <div class='menu-item'> <a  href='/Dictionary/SearchedWords.jsp'data-toggle='modal'>                                                          <i class='glyphicon glyphicon-search'></i>                                "
								+ " <p>My Search History</p>   "
								+ "  </a>"
								+ " </div>"
								+ "                                                  <div class='menu-item'> "
								+ "                            <a  href='/Dictionary/SelectQuiz' data-toggle='modal'>"
								+ "                                 <i class='glyphicon glyphicon-list-alt'></i>"
								+ "                                 <p  >Attend Quiz</p>"
								+ "                             </a>"
								+ "                         </div> "
								+ "                                                 <div class='menu-item'>"
								+ "                             <a href='/Dictionary/UQuizReport.jsp' data-toggle='modal'>   "
								+ "                              <i class='material-icons'>insert_chart</i>                                 <p>My report</p>                             </a>                         </div>   "
								+"                                           <div class='menu-item'> 						                           <a  href='Hangman.jsp' data-toggle='modal'>						                                 <i class='fa fa-gamepad' aria-hidden='true'></i>						                                <p  >Play</p>						                            </a>						                        </div> "
								
								+"</div>                                          <div class='col-md-6'>                                                  <!-- Start Carousel Section -->                                                                                 <br> <br>                            <br> <br>                                 <!-- Wrapper for slides -->                                 <div class='carousel-inner'>                                     <div class='item active'>                 <form action='/Dictionary/SearchMeaning.jsp'>       <input list='search1' name='search' class='form-control'>  <datalist id='search1' > ");
								WordDao wd=new WordDao();
								List<WordBean> wb=wd.getWords();
								for(WordBean w:wb)
								{
				                out.println("   <option value='"+w.getWord()+"'>");
								}
				                out.println(" </datalist>                                     <input type='submit' class='form-control'   onclick='check()' value='Search'/></form>                                     </div>                                                                      </div>                             <br> <br> <br> <br>    <br> <br>                                                     <!-- Start Carousel Section -->                                                  <div class='row'>                             <div class='col-md-6'>                                 <div class='menu-item ' >                                     <a href='/Dictionary/UserInterface/browse.html' data-toggle='modal'>                                        <i class='material-icons'>live_help</i>                                         <p >Browse</p>                                     </a>                                 </div>                             </div>                                                          <div class='col-md-6'>                                 <div class='menu-item'>                                     <a href='/Dictionary/TotalScore.jsp' data-toggle='modal'>                                         <i class='glyphicon glyphicon-star'></i>                                         <p>My Total Score</p>                                     </a>                                 </div>                             </div>                                                      </div>                                              </div>                                          <div class='col-md-3'>                                                  <div class='menu-item'>                             <a href='/Dictionary/Subscribe.jsp' data-toggle='modal'>                                 <i class='fa fa-envelope-o'></i>                                 <p>Mail my Report</p>                             </a>                         </div>                                                  <div class='menu-item '>                             <a href='/Dictionary/LeaderBoard.jsp' data-toggle='modal'>                                 <i class='fa fa-mortar-board'></i>                                 <p>My Rank</p>                             </a>                         </div>                                                  <div class='menu-item'>                             <a href='/Dictionary/RecentScore.jsp' data-toggle='modal'>                                 <i class='glyphicon glyphicon-star-empty'></i>                                 <p>My Recent Score</p>                             </a>                         </div>     ");
								if(new SubUserDao().checkUser(eid))
								{
									out.print("                                           <div class='menu-item'> 						                           <a  href='unsubscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >UnSubscribe</p>						                            </a>						                        </div> ");
									}
								else
								out.print("                                           <div class='menu-item'> 						                           <a  href='daily_subscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >Subscribe</p>						                            </a>						                        </div> ");
								out.println("<a href='Hangman.jsp'>Play</a> <i class='fa fa-gamepad' aria-hidden='true'></i>  ");
								out.print("</body>      </html>");	}
			else if(res==-1)
			{
				 
				out.println("<!DOCTYPE html><html><head><meta charset='ISO-8859-1'><style>body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }.fcenter{  float:center; }#formCentre{  position: absolute;    left: 500px;    top: 150px;     width:500px;  height:500px;}</style>  <meta charset='utf-8'>  <meta name='viewport' content='width=device-width, initial-scale=1'>  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script >   <script src='/Dictionary/UserInterface/signup.js'></script><title>SignUp</title>  <link rel='shortcut icon' href='images/ticon.ico' /></head><body onload=loadJSON()><div class='fcenter' style='color:white;font-family:'Comic Sans MS''><fieldset id='formCentre' ><legend class='panel-heading' style='color:white;font-family:'Comic Sans MS''>Sign Up</legend><form class='panel-body'  action='/Dictionary/IndexPage' method='post'><div class='form-group'>  <label for='usr'>Name:</label>  <input type='text' class='form-control' id='name' name='name'></div><div class='form-group'>  <label for='email'>EmailId:</label>  <input type='email' class='form-control' id='email' name='email'></div><div class='form-group'>  <label for='pwd'>Password:</label>  <input type='password' class='form-control' id='pwd' name='pwd'></div><div class='form-group'>  <label for='cpwd'>Confirm Password:</label>  <input type='password' class='form-control' id='cpwd'></div><div class='form-group'>  <label for='country'>Country:</label>  <select class='form-control' id='country'  >            </select></div><p>This emailid already holds an account</p><input type='hidden' name='ls' value='2'/> <div class='form-group'><input type='submit' class='btn btn-primary btn-block'  onclick='return onFinish()' value='submit' /></div></form></fieldset></div></body></html>");
			}
			else
				logger.info("SignUp Failed..");
		}
		
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//out.print("<html><body>HI</body></html>");
		int ls=Integer.parseInt(request.getParameter("ls"));
		if(ls==1){
			HttpSession httpS=request.getSession(true);
			
		String eid=request.getParameter("email");
		String pwd=request.getParameter("pwd");
		
		UserDao ud=new UserDao();
		logger.info(eid+" "+pwd);
		//con = DaoHelper.getConnection();
		
		int s=ud.login(eid, pwd);
	
			if(!httpS.isNew())
			{
				eid=(String) httpS.getAttribute("emailId");
			}
			
		
			
			System.out.println("IN GET REQUEST"+eid);
		if((s==1  || !httpS.isNew()) && eid!=null)
		{		
			System.out.println("*innnn*");
		HttpSession httpSession=request.getSession(true);
		httpSession.setAttribute("emailId", eid);
		
		out.print("<!DOCTYPE html> <html lang='en'>     "
				+ "<head>         "
				+ "<meta charset='utf-8'> "
				+ "        <meta http-equiv='X-UA-Compatible' content='IE=edge'>"
				+ "         <meta name='viewport' content='width=device-width, initial-scale=1'>         "
				+ "<meta name='description' content=''>  "
				+ "       <meta name='author' content=''>       "
				+ "  <link rel='shortcut icon' href='/Dictionary/UserInterface/images/ticon.ico' />     "
				+ "    <style>             "
				+ " #llist{        "
				+ "         position:absolute;     "
				+ "         right:10px;             "
				+ "          top:10px;                         "
				+ "   }             "
				+ " body{              font-family:'Comic Sans MS';} ul { list-style-type: none; padding: 0;   width: 200px; border: 1px solid red; display: none;}ul li a {display: block;} "
				+ "       </style>          "
				+ "<script src='/Dictionary/UserInterface/js/index.js'></script> <script src='/Dictionary/UserInterface/js/jquery-2.1.1.min.js'></script>  "
				+ "       <title>~ A ~ TO ~ Z ~ </title>         "
				+ "<link href='https://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>    "
				+ "     <!-- Bootstrap Core CSS -->       "
				
				
         		+ "  <link href='/Dictionary/UserInterface/bootstrap/css/bootstrap.min.css' rel='stylesheet'>  "
				+ "       <!-- Font Awesome CSS -->        "
				+ " <link href='/Dictionary/UserInterface/css/font-awesome.min.css' rel='stylesheet'> 	"
				+ "	 		<!-- Custom CSS -->        "
				+ " <link href='/Dictionary/UserInterface/css/animate.css' rel='stylesheet'>     "
				+ "    <!-- Custom CSS -->        "
				+ " <link href='/Dictionary/UserInterface/css/style.css' rel='stylesheet'>   "
				+ "      <!-- Custom Fonts -->        "
				+ " <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>                 <!--[if lt IE 9]>          "
				+ "   <script src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js'></script> "
				+ "    <script src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js'></script>"
				+ "         <![endif]-->     </head>      "
				+ "    <body>                 "
				+ " <!-- Start Logo Section -->         "
				+ "<section id='logo-section' class='text-center'>        "
				+ "     <div class='container'>               "
				+ "  <div class='row'>                     "
				+ "<div class='col-md-12'>                         "
				+ "<div class='logo text-center'>                             "
				+ "<h1>~ A ~ TO ~ Z ~</h1>                             "
				+ "<span>Dictionary</span>                         "
				+ "</div>                     "
				+ "</div>                                     "
				+ "</div>            "
				+ " </div>        "
				+ " </section>         "
				+ "<!-- End Logo Section -->        "
				+ " <div id='llist'>"
				+ " <a style='color:red;font-family:'Comic Sans MS';font-size:20px' >"+eid+"</a> <a href='/Dictionary/Login?lg=3'>Logout</a>");
						if(eid.equals("jananibala2512@gmail.com")){
							System.out.print("inside admin"+eid);
						out.println( "&nbsp;&nbsp;<a href='/Dictionary/UserInterface/insertQuiz.html'>Insert Quiz</a>");
						out.println( "&nbsp;&nbsp;<a href='/Dictionary/InsertWord.jsp'>Insert Word</a>");
						out.println( "&nbsp;&nbsp;<a href='/Dictionary/UpdateWord.html'>Update Word</a>");
						}
						else
						{
							logger.info("not inside admin"+eid);
						}
						out.println("</div><!-- Start Main Body Section -->         <div class='mainbody-section text-center'>             <div class='container'>                 <div class='row'>                                          <div class='col-md-3'>                                                  <div class='menu-item'>                             <a  href='/Dictionary/SearchedWords.jsp'data-toggle='modal'>                                 <i class='glyphicon glyphicon-search'></i>                                "
						+ " <p>My Search History</p>   "
						+ "  </a>"
						+ " </div>"
						+ "                                                  <div class='menu-item'> "
						+ "                            <a  href='/Dictionary/SelectQuiz' data-toggle='modal'>"
						+ "                                 <i class='glyphicon glyphicon-list-alt'></i>"
						+ "                                 <p  >Attend Quiz</p>"
						+ "                             </a>"
						+ "                         </div> "
						+ "                                                 <div class='menu-item'>"
						+ "                             <a href='/Dictionary/UQuizReport.jsp' data-toggle='modal'>   "
						+ "                              <i class='material-icons'>insert_chart</i>                                 <p>My report</p>                             </a>                         </div>"
						+"                                           <div class='menu-item'> 						                           <a  href='Hangman.jsp' data-toggle='modal'>						                                 <i class='fa fa-gamepad' aria-hidden='true'></i>						                                <p  >Play</p>						                            </a>						                        </div> "
						
						+"</div>                                          <div class='col-md-6'>                                                  <!-- Start Carousel Section -->                                                                                 <br> <br>                            <br> <br>                                 <!-- Wrapper for slides -->                                 <div class='carousel-inner'>                                     <div class='item active'>                              <form action='/Dictionary/SearchMeaning.jsp'><input list='search1' class='form-control' name='search'>  <datalist id='search1' > ");
								WordDao wd=new WordDao();
								List<WordBean> wb=wd.getWords();
								for(WordBean w:wb)
				                out.println("   <option value='"+w.getWord()+"'>");
								out.println(" </datalist> <input type='submit' class='form-control'  onclick='check()' value='Search'/>    </form>                                 </div>                                                                      </div>                             <br> <br> <br> <br>    <br> <br>                                                     <!-- Start Carousel Section -->                                                  <div class='row'>                             <div class='col-md-6'>                                 <div class='menu-item ' >                                     <a href='/Dictionary/UserInterface/browse.html' data-toggle='modal'>                                        <i class='material-icons'>live_help</i>                                         <p >Browse</p>                                     </a>                                 </div>                             </div>                                                          <div class='col-md-6'>                                 <div class='menu-item'>                                     <a href='/Dictionary/TotalScore.jsp' data-toggle='modal'>                                         <i class='glyphicon glyphicon-star'></i>                                         <p>My Total Score</p>                                     </a>                                 </div>                             </div>                                                      </div>                                              </div>                                          <div class='col-md-3'>                                                  <div class='menu-item'>                             <a href='/Dictionary/Subscribe.jsp' data-toggle='modal'>                                 <i class='fa fa-envelope-o'></i>                                 <p>Mail my Report</p>                             </a>                         </div>                                                  <div class='menu-item '>                             <a href='/Dictionary/LeaderBoard.jsp' data-toggle='modal'>                                 <i class='fa fa-mortar-board'></i>                                 <p>My Rank</p>                             </a>                         </div>                                                  <div class='menu-item'>                             <a href='/Dictionary/RecentScore.jsp' data-toggle='modal'>                                 <i class='glyphicon glyphicon-star-empty'></i>                                 <p>My Recent Score</p>                             </a>                         </div>  ");
								if(new SubUserDao().checkUser(eid))
								{
									out.print("                                           <div class='menu-item'> 						                           <a  href='unsubscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >UnSubscribe</p>						                            </a>						                        </div> ");
									}
								else
								out.print("                                           <div class='menu-item'> 						                           <a  href='daily_subscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >Subscribe</p>						                            </a>						                        </div> ");
								 out.println("<a href='Hangman.jsp'>Play</a> <i class='fa fa-gamepad' aria-hidden='true'></i>  ");
								out.print("</body>      </html>");    }
		else
		{
			
	    // out.print("invalid Credentials!");  
       // RequestDispatcher rd=request.getRequestDispatcher("/UserInterface/Login.html");  
       // rd.include(request, response);  
			
			out.println("<!DOCTYPE html><html><head><meta charset='ISO-8859-1'><style>body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }.fcenter{  float:center; }#formCentre{  position: absolute;    left: 500px;    top: 150px;     width:500px;  height:500px;}</style>  <link rel='shortcut icon' href='images/ticon.ico' />  <meta charset='utf-8'>  <meta name='viewport' content='width=device-width, initial-scale=1'>  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>   <script>  function onFinish(){	var password=document.getElementById('pwd').value;	var ppattern1='[0-9]';	var ppattern2='[a-zA-z]';		if(document.getElementById('email').value=='')	{	document.getElementById('email').focus();	alert('enter EmailId');	return false;	}	else if(password=='')	{	document.getElementById('pwd').focus();		alert('enter password');	return false;	}		return true;		}  </script><title>Login</title></head><body ><div class='fcenter' style='color:white;font-family:'Comic Sans MS''><fieldset id='formCentre' ><legend class='panel-heading' style='color:white;font-family:'Comic Sans MS''>Login</legend><form class='panel-body'   method='post' action='/Dictionary/IndexPage'><div class='form-group'>  <label for='email'>EmailId:</label>  <input name='email' type='email' class='form-control' id='email'></div><div class='form-group'>  <label for='pwd'>Password:</label>  <input type='password' class='form-control' id='pwd'  name='pwd'></div><input type='hidden' name='ls' value='1'/> <p style='color:'red''>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Invalid details</p><div class='form-group'><button type='submit' onclick='return onFinish()'  class='btn btn-primary btn-block'>Login</button></div></form></fieldset></div><p>#Invalid Details</p></body></html>");
			
		}
		}
		else if(ls==2)
		{
			String name=request.getParameter("name");
			String eid=request.getParameter("email");
			String pwd=request.getParameter("pwd");
			String country=request.getParameter("country");
			
			UserBean uBean=new UserBean();
		    UserDao userDao=new UserDao();
			uBean.setEmailId(eid);
			uBean.setPassword(pwd);
			uBean.setName(name);
			uBean.setCountry(country);
			
			int res=userDao.signUp(uBean);
			if(res==1){
				Cookie cookies=new Cookie("emailId",eid);
				response.addCookie(cookies);
				
				out.print("<!DOCTYPE html> <html lang='en'>     "
						+ "<head>         "
						+ "<meta charset='utf-8'> "
						+ "        <meta http-equiv='X-UA-Compatible' content='IE=edge'>"
						+ "         <meta name='viewport' content='width=device-width, initial-scale=1'>         "
						+ "<meta name='description' content=''>  "
						+ "       <meta name='author' content=''>       "
						+ "  <link rel='shortcut icon' href='/Dictionary/UserInterface/images/ticon.ico' />     "
						+ "    <style>             "
						+ " #llist{        "
						+ "         position:absolute;     "
						+ "         right:10px;             "
						+ "          top:10px;                         "
						+ "   }             "
						+ " body{              font-family:'Comic Sans MS';}  "
						+ "       </style>          "
						+ "<script src='/Dictionary/UserInterface/js/index.js'></script> <script src='/Dictionary/UserInterface/js/jquery-2.1.1.min.js'></script>  "
						+ "       <title>~ A ~ TO ~ Z ~ </title>         "
						+ "<link href='https://fonts.googleapis.com/icon?family=Material+Icons' rel='stylesheet'>    "
						+ "     <!-- Bootstrap Core CSS -->       "
						
						
		         		+ "  <link href='/Dictionary/UserInterface/bootstrap/css/bootstrap.min.css' rel='stylesheet'>  "
						+ "       <!-- Font Awesome CSS -->        "
						+ " <link href='/Dictionary/UserInterface/css/font-awesome.min.css' rel='stylesheet'> 	"
						+ "	 		<!-- Custom CSS -->        "
						+ " <link href='/Dictionary/UserInterface/css/animate.css' rel='stylesheet'>     "
						+ "    <!-- Custom CSS -->        "
						+ " <link href='/Dictionary/UserInterface/css/style.css' rel='stylesheet'>   "
						+ "      <!-- Custom Fonts -->        "
						+ " <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>                 <!--[if lt IE 9]>          "
						+ "   <script src='https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js'></script> "
						+ "    <script src='https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js'></script>"
						+ "         <![endif]-->     </head>      "
						+ "    <body>                 "
						+ " <!-- Start Logo Section -->         "
						+ "<section id='logo-section' class='text-center'>        "
						+ "     <div class='container'>               "
						+ "  <div class='row'>                     "
						+ "<div class='col-md-12'>                         "
						+ "<div class='logo text-center'>                             "
						+ "<h1>~ A ~ TO ~ Z ~</h1>                             "
						+ "<span>Dictionary</span>                         "
						+ "</div>                     "
						+ "</div>                                     "
						+ "</div>            "
						+ " </div>        "
						+ " </section>         "
						+ "<!-- End Logo Section -->        "
						+  " <div id='llist'>"
				+ " <a style='color:red;font-family:'Comic Sans MS';font-size:20px' >"+eid+"</a> <a href='/Dictionary/Login?lg=3'>Logout</a>");
				if(eid=="jananibala2512@gmail.com"){
					out.println( "&nbsp;&nbsp;<a href='/Dictionary/UserInterface/insertQuiz.html'>Insert Quiz</a>");
					out.println( "&nbsp;&nbsp;<a href='/Dictionary/InsertWord.jsp'>Insert Word</a>");
					}
					
						
						out.print("</div><!-- Start Main Body Section -->         <div class='mainbody-section text-center'>             <div class='container'>                 <div class='row'>                                          <div class='col-md-3'>                                                  <div class='menu-item'> <a  href='/Dictionary/SearchedWords.jsp'data-toggle='modal'>                                                          <i class='glyphicon glyphicon-search'></i>                                "
								+ " <p>My Search History</p>   "
								+ "  </a>"
								+ " </div>"
								+ "                                                  <div class='menu-item'> "
								+ "                            <a  href='/Dictionary/SelectQuiz' data-toggle='modal'>"
								+ "                                 <i class='glyphicon glyphicon-list-alt'></i>"
								+ "                                 <p  >Attend Quiz</p>"
								+ "                             </a>"
								+ "                         </div> "
								+ "                                                 <div class='menu-item'>"
								+ "                             <a href='/Dictionary/UQuizReport.jsp' data-toggle='modal'>   "
								+ "                              <i class='material-icons'>insert_chart</i>                                 <p>My report</p>                             </a>                         </div> "
								+"                                           <div class='menu-item'> 						                           <a  href='Hangman.jsp' data-toggle='modal'>						                                 <i class='fa fa-gamepad' aria-hidden='true'></i>						                                <p  >Play</p>						                            </a>						                        </div> "
								
								+"</div>                                          <div class='col-md-6'>                                                  <!-- Start Carousel Section -->                                                                                 <br> <br>                            <br> <br>                                 <!-- Wrapper for slides -->                                 <div class='carousel-inner'>                                     <div class='item active'>                 <form action='/Dictionary/SearchMeaning.jsp'>       <input list='search1' name='search' class='form-control'>  <datalist id='search1' > ");
								WordDao wd=new WordDao();
								List<WordBean> wb=wd.getWords();
								for(WordBean w:wb)
								{
				                out.println("   <option value='"+w.getWord()+"'>");
								}
				                out.println(" </datalist>                                     <input type='submit' class='form-control'   onclick='check()' value='Search'/></form>                                     </div>                                                                      </div>                             <br> <br> <br> <br>    <br> <br>                                                     <!-- Start Carousel Section -->                                                  <div class='row'>                             <div class='col-md-6'>                                 <div class='menu-item ' >                                     <a href='/Dictionary/UserInterface/browse.html' data-toggle='modal'>                                        <i class='material-icons'>live_help</i>                                         <p >Browse</p>                                     </a>                                 </div>                             </div>                                                          <div class='col-md-6'>                                 <div class='menu-item'>                                     <a href='/Dictionary/TotalScore.jsp' data-toggle='modal'>                                         <i class='glyphicon glyphicon-star'></i>                                         <p>My Total Score</p>                                     </a>                                 </div>                             </div>                                                      </div>                                              </div>                                          <div class='col-md-3'>                                                  <div class='menu-item'>                             <a href='/Dictionary/Subscribe.jsp' data-toggle='modal'>                                 <i class='fa fa-envelope-o'></i>                                 <p>Mail my Report</p>                             </a>                         </div>                                                  <div class='menu-item '>                             <a href='/Dictionary/LeaderBoard.jsp' data-toggle='modal'>                                 <i class='fa fa-mortar-board'></i>                                 <p>My Rank</p>                             </a>                         </div>                                                  <div class='menu-item'>                             <a href='/Dictionary/RecentScore.jsp' data-toggle='modal'>                                 <i class='glyphicon glyphicon-star-empty'></i>                                 <p>My Recent Score</p>                             </a>                         </div> ");
								if(new SubUserDao().checkUser(eid))
								{
									out.print("                                           <div class='menu-item'> 						                           <a  href='unsubscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >UnSubscribe</p>						                            </a>						                        </div> ");
									}
								else
								out.print("                                           <div class='menu-item'> 						                           <a  href='daily_subscribe.jsp' data-toggle='modal'>						                                <i  class='fa fa-envelope-o'></i>					                                <p  >Subscribe</p>						                            </a>						                        </div> ");
								
				                
				                out.println("<a href='Hangman.jsp'>Play</a> <i class='fa fa-gamepad' aria-hidden='true'></i>  ");
				                
								out.print("</body>      </html>");
			}
			else if(res==-1)
			{
				 
				out.println("<!DOCTYPE html><html><head><meta charset='ISO-8859-1'><style>body {    background: url('/Dictionary/UserInterface/images/index.jpg') no-repeat;    background-attachment: fixed;    background-size: cover;    background-position: 50% 50%;    color:white;font-family:'Comic Sans MS';    }.fcenter{  float:center; }#formCentre{  position: absolute;    left: 500px;    top: 150px;     width:500px;  height:500px;}</style>  <meta charset='utf-8'>  <meta name='viewport' content='width=device-width, initial-scale=1'>  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>  <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script >   <script src='/Dictionary/UserInterface/signup.js'></script><title>SignUp</title>  <link rel='shortcut icon' href='images/ticon.ico' /></head><body onload=loadJSON()><div class='fcenter' style='color:white;font-family:'Comic Sans MS''><fieldset id='formCentre' ><legend class='panel-heading' style='color:white;font-family:'Comic Sans MS''>Sign Up</legend><form class='panel-body'  action='/Dictionary/IndexPage' method='post'><div class='form-group'>  <label for='usr'>Name:</label>  <input type='text' class='form-control' id='name' name='name'></div><div class='form-group'>  <label for='email'>EmailId:</label>  <input type='email' class='form-control' id='email' name='email'></div><div class='form-group'>  <label for='pwd'>Password:</label>  <input type='password' class='form-control' id='pwd' name='pwd'></div><div class='form-group'>  <label for='cpwd'>Confirm Password:</label>  <input type='password' class='form-control' id='cpwd'></div><div class='form-group'>  <label for='country'>Country:</label>  <select class='form-control' id='country'  >            </select></div><p>This emailid already holds an account</p><input type='hidden' name='ls' value='2'/> <div class='form-group'><input type='submit' class='btn btn-primary btn-block'  onclick='return onFinish()' value='submit' /></div></form></fieldset></div></body></html>");
			}
			else
				logger.info("SignUp Failed..");
		}
	   
	
	}

}
