package com.atoz.servlets;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet Filter implementation class CheckFilter
 */

public class CheckFilter implements Filter {

    /**
     * Default constructor. 
     */
    public CheckFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
	System.out.println("in filter");
	HttpSession session=((HttpServletRequest)request).getSession(true);
	String emailId=(String) session.getAttribute("emailId");
	if(emailId==null)
	   emailId=request.getParameter("email");
	Cookie c[]=((HttpServletRequest)request).getCookies();
	if(c!=null)
	{
	for(int i=0;i<c.length;i++)
	{
		if(c[i].getName().equals("emailId"))
			emailId=c[i].getValue();
			
	}

	System.out.println("filter**"+emailId);
	if(emailId==null)
		((HttpServletResponse)response).sendRedirect("/Dictionary/UserInterface/Login.html");
	}
		chain.doFilter(request, response);
		
		System.out.println("after filter");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
