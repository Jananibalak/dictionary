package com.atoz.scheduler;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.impl.JobDetailImpl;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.triggers.SimpleTriggerImpl;

import com.atoz.mail.SendMail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.impl.JobDetailImpl;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.triggers.SimpleTriggerImpl;

import com.atoz.mail.SendMail;
/**
 * Servlet implementation class StartMai
 */
@WebServlet("/StartMail1")
public class StartMail1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	public void init() throws ServletException{
		  // Initialization code...
		SchedulerFactory factory = new StdSchedulerFactory();
		Scheduler scheduler;
		try {
			scheduler = factory.getScheduler();
		

		//Creating Job and link to our Job class
		JobDetailImpl jobDetail = new JobDetailImpl();
		jobDetail.setName("Mail Job");
		jobDetail.setJobClass(SendMail.class);

		//Creating schedule time with trigger
		SimpleTriggerImpl simpleTrigger = new SimpleTriggerImpl();
		simpleTrigger.setStartTime(new Date(System.currentTimeMillis() + 1000));
		simpleTrigger.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
		//daily
		simpleTrigger.setRepeatInterval(24L * 60L * 60L * 1000L);
		
		simpleTrigger.setName("FirstTrigger");

		//Start scheduler
	
			scheduler.start();
	
		
			scheduler.scheduleJob(jobDetail,simpleTrigger);
		}
		 catch (SchedulerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		}
    public StartMail1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
