package com.atoz.scheduler;

import java.util.Date;

import javax.servlet.http.HttpServlet;

import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.impl.JobDetailImpl;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.triggers.SimpleTriggerImpl;

import com.atoz.mail.SendMail;

public class StartMail extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String args[]) throws SchedulerException{
		//Creating scheduler factory and scheduler
		SchedulerFactory factory = new StdSchedulerFactory();
		Scheduler scheduler = factory.getScheduler();

		//Creating Job and link to our Job class
		JobDetailImpl jobDetail = new JobDetailImpl();
		jobDetail.setName("Mail Job");
		jobDetail.setJobClass(SendMail.class);

		//Creating schedule time with trigger
		SimpleTriggerImpl simpleTrigger = new SimpleTriggerImpl();
		simpleTrigger.setStartTime(new Date(System.currentTimeMillis() + 1000));
		simpleTrigger.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
		//daily
		simpleTrigger.setRepeatInterval(24L * 60L * 60L * 1000L);
		//minute
		//simpleTrigger.setRepeatInterval(60L * 1000L);
		simpleTrigger.setName("FirstTrigger");

		//Start scheduler
		scheduler.start();
		scheduler.scheduleJob(jobDetail,simpleTrigger);
	}
}