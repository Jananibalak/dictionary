package com.atoz.mail;

import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.quartz.Job;

import com.atoz.common.*;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
public class SendMail implements Job {

	public void send(String to_eid,List<QuizResultBean> list_qrd ) throws AddressException, MessagingException 
    {
         
           //System.out.println(obj.getEmail_id() + obj.getPassword());

           String to = to_eid;

          // Sender's email ID needs to be mentioned
          String from = "janani.balakrishnan@bnymellon.com";

          // Assuming you are sending email from localhost
          String host = "smtp.bnymellon.net";

          // Get system properties
          Properties properties = System.getProperties();

          // Setup mail server
          properties.setProperty("mail.smtp.host", host);

          // Get the default Session object.
          Session session = Session.getDefaultInstance(properties);

         
             // Create a default MimeMessage object.
             MimeMessage message = new MimeMessage(session);

             // Set From: header field of the header.
             message.setFrom(new InternetAddress(from));

             // Set To: header field of the header.
             message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

             String report="";
             if(list_qrd!=null)
             {
             for(QuizResultBean qrb:list_qrd)
             {
             	  report+="QuizId:"+qrb.getQuizId()+"\n";
             	 report+="Time of attempt:"+qrb.getTimeOfAttempt()+"\n";
             	report+="no of questions:"+qrb.getNoOfQuestions()+"\n";
             	report+="no of attempted:"+qrb.getNoOfattempted()+"\n";
             	report+="no of correct:"+qrb.getNoOfcorrect()+"\n";
             	report+="score:"+qrb.getScore()+"\n";
             	
             }
             }
             // Set Subject: header field
             message.setSubject("Report");

             // Now set the actual message
             message.setText(report);

             // Send message
             Transport.send(message);
             
         

    }     
	@Override
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
	
		  //System.out.println(obj.getEmail_id() + obj.getPassword());
     List<SubUserBean> list=new SubUserDao().getSubUsers();
     for(SubUserBean sub:list)
     {
        String to = sub.getEid();
System.out.println(to);
       // Sender's email ID needs to be mentioned
       String from = "janani.balakrishnan@bnymellon.com";

       // Assuming you are sending email from localhost
       String host = "smtp.bnymellon.net";

       // Get system properties
       Properties properties = System.getProperties();

       // Setup mail server
       properties.setProperty("mail.smtp.host", host);

       // Get the default Session object.
       Session session = Session.getDefaultInstance(properties);

      
          // Create a default MimeMessage object.
          MimeMessage message = new MimeMessage(session);

          // Set From: header field of the header.
          try {
			message.setFrom(new InternetAddress(from));
		

          // Set To: header field of the header.
          message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
          WordBean wb=new WordDao().getWordDetails(sub.getWid());
          
          String report="word: "+wb.getWord()+"\n"+"Meaning: "+wb.getMeaning();
         
          // Set Subject: header field
          message.setSubject("Learn a word today");

          // Now set the actual message
          message.setText(report);

          // Send message
          Transport.send(message);
          new SubUserDao().updateWID(sub.getEid());
          sub.getEid();
          } catch (AddressException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		} catch (MessagingException e) {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
     }
          
      
	}
	public static void main(String args[]) throws AddressException, MessagingException
	{
		boolean isValid = false;
		try {
			//
			// Create InternetAddress object and validated the supplied
			// address which is this case is an email address.
			InternetAddress internetAddress = new InternetAddress("jana@gg.com");
			internetAddress.validate();
			System.out.println("You: " );
			isValid = true;
		} catch (AddressException e) {
			System.out.println("You are in catch block -- Exception Occurred for: " );
		}
		//new SendMail().send("um@gmai11.com",null);
	}
	
}
