package com.atoz.common;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.xml.bind.annotation.XmlRootElement;


@SuppressWarnings("restriction")
@XmlRootElement(name="words")
@ApiModel
public class WordBean {
	@ApiModelProperty(position=1,required=true,value="Describes word")
	String word;
	@ApiModelProperty(position=2,required=true,value="Type of Word")
	String type;
	@ApiModelProperty(position=3,required=true,value="Meaning of Word")
	String meaning;
	@ApiModelProperty(position=4,required=true,value="Frequency of Word")
	int frequency;
	@ApiModelProperty(position=5,required=true,value="Id of Word")
	int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	
	}
	public String getMeaning() {
		return meaning;
	}
	public void setMeaning(String meaning) {
		this.meaning = meaning;
	}
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	
	
	
	
	

}
