package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SearchedWordDao {
public List<SearchedWordBean> getWords(String emailId){
		
		
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		ResultSet resultset = null;
		List<SearchedWordBean> WordList = null;
		try {
			 stmt = conn.createStatement();
		   
		    	 int i;
		    	 String searchQuery="select * from T_XBBNHBG_Search where emailid='"+emailId+"'";
		    	
					resultset = stmt.executeQuery(searchQuery);
		     
			WordList = new ArrayList<SearchedWordBean>();
			while(resultset.next()) {
				SearchedWordBean wordBean = new SearchedWordBean();
				
				wordBean.setWord(resultset.getString(2));
				wordBean.setTime(resultset.getString(3));
			
				WordList.add(wordBean);
						
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
				if(resultset!=null)
					resultset.close();
					
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return WordList;
			
	}
}
