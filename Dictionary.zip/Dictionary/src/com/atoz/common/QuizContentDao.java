package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class QuizContentDao {
	
	public List<QuizContentBean> retrieveContent(String quizId)
	{
		
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		ResultSet resultset = null;
		List<QuizContentBean> qcList= null;
		try {
			 stmt = conn.createStatement();
		     
			 String searchQuery="select * from T_XBBNHBG_QUIZCONTENT where QUIZID='"+quizId+"'";
			resultset = stmt.executeQuery(searchQuery);			
			
			qcList = new ArrayList<QuizContentBean>();
			//List<WordBean>wList  = new ArrayList<WordBean>();
			while(resultset.next()) {
				String QID=resultset.getString(1);
				QuizContentBean QCBean = new QuizContentBean();
				QCBean.setQuestion(resultset.getString(2));
				QCBean.setAnswer(resultset.getString(3));
				QCBean.setChoiceList(resultset.getString(4).split(","));
				QCBean.setWeightage(Integer.parseInt(resultset.getString(5)));
					
				
				QCBean.setQuizID(QID);
				
				qcList.add(QCBean);
						
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
				if(resultset!=null)
					resultset.close();
					
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return qcList;
	}
	
	public int insertQuizContent(QuizContentBean qcb)
	{

		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		QuizReportDao qrd=new  QuizReportDao ();
		
		try {
			 stmt = conn.createStatement();
			 String choice="";
              for(int i=0;i<3;i++)
              {
            	  choice+=qcb.getChoiceList()[i]+",";
              }
              choice+=qcb.getChoiceList()[3];
			  String query="INSERT INTO T_XBBNHBG_QUIZCONTENT VALUES('"+qcb.getQuizID()+"','"+qcb.getQuestion()+"','"+qcb.getAnswer()+"','"+choice+"',"+qcb.getWeightage()+")";
		        int r=stmt.executeUpdate(query);
		       
		     
		        if(r==1&&r==1)
		        	return 1;
		        else
		        	return 0;
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return 0;
	}

}
