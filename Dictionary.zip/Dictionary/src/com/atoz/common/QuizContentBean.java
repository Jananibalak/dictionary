package com.atoz.common;

public class QuizContentBean {
	String QuizID;
	String question;
	String answer;
	String[] choiceList;
	int weightage;
	public String getQuizID() {
		return QuizID;
	}
	public void setQuizID(String quizID) {
		QuizID = quizID;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String[] getChoiceList() {
		return choiceList;
	}
	public void setChoiceList(String[] choiceList) {
		this.choiceList = choiceList;
	}
	public int getWeightage() {
		return weightage;
	}
	public void setWeightage(int weightage) {
		this.weightage = weightage;
	}

}
