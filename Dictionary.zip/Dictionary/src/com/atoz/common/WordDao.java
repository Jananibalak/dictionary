package com.atoz.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.sql.Types;

import javax.sql.DataSource;
import javax.swing.JFileChooser;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

@Component
public class WordDao extends JdbcDaoSupport {
	@Autowired
	public WordDao(DataSource datasource) {
		// TODO Auto-generated constructor stub
		System.out.print("inside dao cons1");
		setDataSource(datasource);
	}
	public WordDao() {
		// TODO Auto-generated constructor stub
		System.out.print("inside dao cons");
	
	}
	public List<WordBean> getAllWords(){
		 String searchQuery="select * from T_XBBNHBG_WORDS";
		 List<WordBean> l=new ArrayList<WordBean>();
			l= getJdbcTemplate().query(searchQuery,new WRowMapper());
			return l;
		 
	}
public List<WordBean> getWord(String word){
		
		
		
		
		     
			 String searchQuery="select * from T_XBBNHBG_WORDS where UPPER(word)='"+word.toUpperCase()+"'";
			 List<WordBean> l=new ArrayList<WordBean>();
				l= getJdbcTemplate().query(searchQuery,new WRowMapper());
		
			
		
			return l;
	}

public List<WordBean> getWords(char ... c){
		
		
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		ResultSet resultset = null;
		List<WordBean> WordList = null;
		try {
			 stmt = conn.createStatement();
		     if(c.length==0){
			 String searchQuery="select * from T_XBBNHBG_WORDS";
			resultset = stmt.executeQuery(searchQuery);}
		     else
		     {
		    	 int i;
		    	 String searchQuery="select * from T_XBBNHBG_WORDS where word like '";
		    	 for(i=0;i<c.length-1;i++)
		    	 {
		    		 searchQuery=searchQuery+c[i]+"%' or word like '";
		    	 }
		    	 searchQuery=searchQuery+c[c.length-1]+"%' ";
		    	// System.out.println(searchQuery);
					resultset = stmt.executeQuery(searchQuery);
		     }
			WordList = new ArrayList<WordBean>();
			while(resultset.next()) {
				WordBean wordBean = new WordBean();
				wordBean.setWord(resultset.getString(1));
				wordBean.setType(resultset.getString(2));
				wordBean.setMeaning(resultset.getString(3));
				wordBean.setFrequency(Integer.parseInt(resultset.getString(4)));
				wordBean.setId(Integer.parseInt(resultset.getString(5)));
				WordList.add(wordBean);
						
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
				if(resultset!=null)
					resultset.close();
					
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return WordList;
			
	}

public int insertWordFromFile(){
	JFileChooser fc= new JFileChooser();
    int ret = fc.showOpenDialog(null);
    int count=0;
    if (ret== JFileChooser.APPROVE_OPTION) 
    {
        File f = fc.getSelectedFile();
    	//File f=new File("C:/Users/XBBNHBG/workspace/Dictionary/C_words.txt");
    	try (BufferedReader br = new BufferedReader(new FileReader(f))) {
    	    String line;
    	    WordBean wBean=new WordBean();
    	    while ((line = br.readLine()) != null) {
    	    	int close = line.indexOf(')');
    	        int open = line.indexOf('(');
    	        if(close!=-1 && open!=-1){
    	        //System.out.println(open+" "+close);
    	        wBean.setWord(line.substring(0, open).trim());
    	        if(line.substring(open + 1, close).trim()=="")
    	        	wBean.setType("-"); 
    	        else
    	        wBean.setType(line.substring(open + 1, close).trim()); 
    	        wBean.setMeaning(line.substring(close + 1).trim());
    	        wBean.setFrequency(0);
    	        Map<Character,Integer> allCount=getCountOfRows();
    			wBean.setId(allCount.get('-'));
    	        count=count+insertWord(wBean);
    	        br.readLine();
    	        }
    	    }
    	} catch (FileNotFoundException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	} catch (IOException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    	
        }
    }
    

	return count;

}
public int insertWord(WordBean wordBean){
	

	
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;
	
	try {
		if(conn==null)
			System.out.println("CONNECTION IS NULL");
		 stmt = conn.createStatement();
		 String word=wordBean.getWord();
	        String type=wordBean.getType();
	        String meaning=wordBean.getMeaning();
	        int frequency=wordBean.getFrequency();
	        
	       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
	       /*derby*/String query="INSERT INTO T_XBBNHBG_WORDS(word,wordtype,definition,frequency) VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+")";
	        int r=stmt.executeUpdate(query);
	        if(r==1)
	        	return 1;
	        else
	        	return 0;
		    
	} 
	catch(SQLSyntaxErrorException ex)
	{
		System.out.println("Not in Format..");
	}catch (SQLException e) {
		
		e.printStackTrace();
	}		
	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
     return 0;
		
}
public int insertWordJDBC(WordBean wordBean){
	


		 String word=wordBean.getWord();
	        String type=wordBean.getType();
	        String meaning=wordBean.getMeaning();
	        int frequency=wordBean.getFrequency();
	        
	       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
	       /*derby*/String query="INSERT INTO T_XBBNHBG_WORDS(word,wordtype,definition,frequency) VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+")";
	        int r=getJdbcTemplate().update(query);
	        if(r==1)
	        	return 1;
	        else
	        	return 0;
		    
	} 

	

public int insertSearch(String emailId,String word,String time){
	

	
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;
	
	try {
		 stmt = conn.createStatement();
		
	        int f=1;
	       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
	       /*derby*/
		 String q="select count(*) from T_XBBNHBG_Search where emailid='"+emailId+"' and word='"+word+"'";
		 ResultSet rs=stmt.executeQuery(q);
		 while(rs.next())
		 {
			 if(rs.getInt(1)>0)
				 f=-1;
				 
		 }
		 
		 
		 if(f==1)
		 {
		 String query="INSERT INTO T_XBBNHBG_Search VALUES('"+emailId+"','"+word+"','"+time+"')";
	        int r=stmt.executeUpdate(query);
	        if(r==1)
	        	return 1;
	        else
	        	return 0;
		 }
		 else
			 return 0;
	} 
	catch(SQLSyntaxErrorException ex)
	{
		System.out.println("Not in Format..");
	}catch (SQLException e) {
		
		e.printStackTrace();
	}		
	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
     return 0;
		
}
public int updateMeaning(int id,String word,String meaning){
	int numRows=0;
	System.out.print("update T_XBBNHBG_WORDS set DEFINITION='"+meaning+"' where id="+id+" and word='"+word+"'");
	
	      numRows = getJdbcTemplate().update("update T_XBBNHBG_WORDS set DEFINITION=? where id=? and word=?",new Object[] {meaning,id,word },new int[] { Types.VARCHAR, Types.INTEGER, Types.VARCHAR});
		    return numRows;
	
}
public int updateType(int id,String word,String type){
	
	
		int numRows=0;
		System.out.print("update T_XBBNHBG_WORDS set type='"+type+"' where id="+id+" and word='"+word+"'");
		try {
		      numRows = getJdbcTemplate()
						.update("update T_XBBNHBG_WORDS set wordtype=? where id=? and word=?",
								new Object[]{ type ,id,
								word },
								new int[] { Types.VARCHAR, Types.INTEGER, Types.VARCHAR
										 });
			    return numRows;
		} catch (Throwable e) {
			
			e.printStackTrace();
		}		
		return -1;		
		
}
public int updateFrequency(int id,String word,int frequency){
	
	
	int numRows=0;
	try {
	      numRows = getJdbcTemplate()
					.update("update T_XBBNHBG_WORDS set frequency=? where id=? and word=?",
							new Object[]{frequency ,id,
							word },
							new int[] { Types.VARCHAR, Types.INTEGER, Types.VARCHAR
									 });
		    return numRows;
	} catch (Throwable e) {
		
		e.printStackTrace();
	}		
	return -1;		
		
}
public String getWord(int id)
{
	try{
	String word=getJdbcTemplate().queryForObject(
			"select * from T_XBBNHBG_WORDS where id = ?",
			new Object[] { id }, new IDRowMapper());	
	return word;
	}
	catch(org.springframework.dao.EmptyResultDataAccessException e)
	{
		return "No such id";
	}
	
}
public WordBean getWordDetails(int id)
{
	System.out.println("gwd dao");
	WordBean wordBean = new WordBean();
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;
	ResultSet resultset = null;
	List<WordBean> WordList = null;
	try {
		 stmt = conn.createStatement();
	     
		 String searchQuery="select * from T_XBBNHBG_WORDS where id = "+id;
	resultset=stmt.executeQuery(searchQuery);
		while(resultset.next()) {
		
			wordBean.setWord(resultset.getString(1));
			wordBean.setType(resultset.getString(2));
			wordBean.setMeaning(resultset.getString(3));
			wordBean.setFrequency(Integer.parseInt(resultset.getString(4)));
			wordBean.setId(Integer.parseInt(resultset.getString(5)));
			
					
		}
		return  wordBean;
	} catch (SQLException e) {
		
		e.printStackTrace();
	}	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
			if(resultset!=null)
				resultset.close();
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	return  wordBean;
		
}
public int deleteWord(String word){
	
	
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;
	
	try {
		 stmt = conn.createStatement();

	        
	        String query="delete from T_XBBNHBG_WORDS where word='"+word+"'";
	        int r=stmt.executeUpdate(query);
	       return r;
		    
	} catch (SQLException e) {
		
		e.printStackTrace();
	}	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
     return -1;
		
}
public int deleteWordJDBC(String word){
	
	
	

	        
	        String query="delete from T_XBBNHBG_WORDS where word='"+word+"'";
	        int r=getJdbcTemplate().update(query);
	       return r;
	
		
}
public int deleteWords(char ...c ){
	
	
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;
	ResultSet resultset = null;
	int res;
	try {
		 stmt = conn.createStatement();
		 if(c.length==0){
			 String delQuery="delete from T_XBBNHBG_WORDS ";
			res = stmt.executeUpdate(delQuery);
		    if(res==1)
	        	return 1;
	        else
	        	return -1;}
		     else
		     {
		    	 int i;
		    	 String delQuery="delete from T_XBBNHBG_WORDS where word like '";
		    	 for(i=0;i<c.length-1;i++)
		    	 {
		    		delQuery=delQuery+c[i]+"%' or word like '";
		    	 }
		    	 delQuery=delQuery+c[c.length-1]+"%' ";
		    	 System.out.println(delQuery);
		    	 res = stmt.executeUpdate(delQuery);
		    	
				    if(res==1)
			        	return 1;
			        else
			        	return -1;
		     }
	        
	       
	      
	    
		    
	} catch (SQLException e) {
		
		e.printStackTrace();
	}	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
     return -1;
		
}
public Map<Character,Integer> getCountOfRows(char ... c)
{
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;

	Map<Character,Integer> WordCount = new TreeMap<Character,Integer> ();
	
	if(c.length==0)
	{
		ResultSet resultset = null;
		ResultSet resultset2 = null;
		int count=0;
	try {
		 stmt = conn.createStatement();
	 
		 String searchQuery="select count(*) from T_XBBNHBG_WORDS";
		resultset = stmt.executeQuery(searchQuery);			
		
		while(resultset.next()) {
			count=count+resultset.getInt(1);
		}
		WordCount.put('-', count);
	} catch (SQLException e) {
		
		e.printStackTrace();
	}	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
			if(resultset!=null)
				resultset.close();
				
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	}
	else
	{
		ResultSet resultset = null;
	
	    
		int count=0;
		try {
			 stmt = conn.createStatement();
			 for(int i=0;i<c.length;i++)
			    {
			 String searchQuery="select count(*) from T_XBBNHBG_WORDS where word like '"+Character.toUpperCase(c[i])+"%' or word like '"+Character.toLowerCase(c[i])+"%'";
			resultset = stmt.executeQuery(searchQuery);			
			
			while(resultset.next()) {
				count=count+resultset.getInt(1);
			}
			
				
				WordCount.put(c[i], count);
				count=0;
			    }
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
				
				
					
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	       }
	     }
	
	
	
	return WordCount;
}

}
