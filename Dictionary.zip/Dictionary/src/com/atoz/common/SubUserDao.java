package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SubUserDao {
	public List<SubUserBean> getSubUsers()
	{

		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		List<SubUserBean> rList=new ArrayList<SubUserBean>();
		  
			try {
				 stmt = conn.createStatement();

					
			        
			       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
			       /*derby*/
				  String query="select * from T_XBBNHBG_SubUser";
			        ResultSet r=stmt.executeQuery(query);
			   
			       while(r.next())
			       {
			    	   SubUserBean sub=new SubUserBean();
			    	   sub.setEid(r.getString(1));
			    	   sub.setWid(r.getInt(2));
			    	   rList.add(sub);
			    	   
			       }
			       
			       
				    
			} 
			catch(SQLSyntaxErrorException ex)
			{
				ex.printStackTrace();
			}catch (SQLException e) {
				
				e.printStackTrace();
			}		
			
			finally{
				
				try {
					
					if(conn!=null)
						conn.close();
					if(stmt!=null)
						stmt.close();
								
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			
		     return rList;
	}

	public int updateWID(String eid){
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;
	
	  int r=0;
		try {
			 stmt = conn.createStatement();

				
		        
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/
			  String query="update T_XBBNHBG_SubUser set word_id=word_id+1 where emailid='"+eid+"'";
		        r=stmt.executeUpdate(query);
		   
		       
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return r;
	
	
		
		
		
	}
public int insertSubUser(String eid){
		

		
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		
		try {
			 stmt = conn.createStatement();

				
		        if(!checkUser(eid)){
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/String query="INSERT INTO  T_XBBNHBG_SubUser VALUES('"+eid+"',1)";
		        int r=stmt.executeUpdate(query);
		      
		        }
		        else
		        {
		        	System.out.println("already reg");
		        	return -1;
		        }
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return 0;
			
	}
public int DeleteSubUser(String eid){
	

	
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;
	
	try {
		 stmt = conn.createStatement();

			
	        if(checkUser(eid)){
	       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
	       /*derby*/String query="delete from  T_XBBNHBG_SubUser where emailid='"+eid+"'";
	        int r=stmt.executeUpdate(query);
	      
	        }
	        else
	        {
	        	System.out.println("not reg user");
	        	return -1;
	        }
		    
	} 
	catch(SQLSyntaxErrorException ex)
	{
		ex.printStackTrace();
	}catch (SQLException e) {
		
		e.printStackTrace();
	}		
	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
     return 0;
		
}

public boolean checkUser(String eid) {
	// TODO Auto-generated method stub
	Connection conn = DaoHelper.getConnection();
	Statement stmt = null;

	try {
		int i=0;
		 stmt = conn.createStatement();
	 String query1="select count(*) from  T_XBBNHBG_subuser where emailid='"+eid+"'";
	 
        ResultSet rs=stmt.executeQuery(query1);
        while(rs.next())
        {
        	i=rs.getInt(1);
        }
        if(i==1)
        	return true;
        else return false;
	}
	catch (SQLException e) {
		
		e.printStackTrace();
	}		
	
	finally{
		
		try {
			
			if(conn!=null)
				conn.close();
			if(stmt!=null)
				stmt.close();
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	return false;
}


}
