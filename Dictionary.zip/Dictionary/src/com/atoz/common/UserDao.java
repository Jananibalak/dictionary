package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;



public class UserDao {
	public int signUp(UserBean uBean){
		

		
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		
		try {
			 stmt = conn.createStatement();

				String emailId=uBean.getEmailId();
				String password=uBean.getPassword();
				String name=uBean.getName();
				String country=uBean.getCountry();
		        if(!checkUser(emailId)){
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/String query="INSERT INTO T_XBBNHBG_USER VALUES('"+emailId+"','"+name+"','"+country+"')";
		        int r=stmt.executeUpdate(query);
		        String query1="INSERT INTO T_XBBNHBG_LOGIN VALUES('"+emailId+"','"+password+"')";
		        int r1=stmt.executeUpdate(query1);
		        if(r==1 && r1==1)
		        	return 1;
		        else
		        	return 0;
		        }
		        else
		        {
		        	return -1;
		        }
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return 0;
			
	}
	public int login(String emailId,String password )
	{

		System.out.println("Inssode");
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
	
		try {
			int i=0;
			 stmt = conn.createStatement();
		 String query1="select count(*) from  T_XBBNHBG_LOGIN where emailid='"+emailId+"' and password='"+password+"'";
		 
	        ResultSet rs=stmt.executeQuery(query1);
	        while(rs.next())
	        {
	        	i=rs.getInt(1);
	        }
	        if(i==1)
	        	return 1;
	        else return -1;
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
		
		return -1;
	}
	public int changePassword(String eid, String oldPass,String newPass )
	{

		
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
	    int c=-1;
		try {
			int i=0;
			 stmt = conn.createStatement();
		 String query1="select count(*) from  T_XBBNHBG_LOGIN where emailid='"+eid+"' and password='"+oldPass+"'";
		 
	        ResultSet rs=stmt.executeQuery(query1);
	        while(rs.next())
	        {
	        	i=rs.getInt(1);
	        }
	        if(i==1)
	        	c= 1;
	        else 
	        	c=0;
	        if(c==1)
	        {
	        	String query2=" update  T_XBBNHBG_LOGIN set  password='"+newPass+"' where emailid='"+eid+"'";
	        	int res=stmt.executeUpdate(query2);
	        	if(res==1)
	        		return 1;
	        }
	        else
	        	return -2;
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
		
		return -1;
	}
	public boolean checkUser(String emailId)
	{
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
	
		try {
			int i=0;
			 stmt = conn.createStatement();
		 String query1="select count(*) from  T_XBBNHBG_LOGIN where emailid='"+emailId+"'";
		 
	        ResultSet rs=stmt.executeQuery(query1);
	        while(rs.next())
	        {
	        	i=rs.getInt(1);
	        }
	        if(i==1)
	        	return true;
	        else return false;
		}
		catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
		
		return false;
	}
	
}
