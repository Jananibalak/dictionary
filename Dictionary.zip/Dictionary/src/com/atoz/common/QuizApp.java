package com.atoz.common;


import java.util.List;
import java.util.Scanner;

public class QuizApp {
     
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
	System.out.println("1.Insert new Quiz");
	
	
		 QuizDao qd=new QuizDao();
		List<String> list=qd.listQuiz();
		System.out.println("Already Available Quiz");
		int l=0;
		for(String qi:list)
		{
			System.out.println(l+1+") "+qi);
			l=l+1;
		}
			
		
	QuizBean qb=new QuizBean();
	System.out.println("--------Enter QuizId:");
	String quizid=in.nextLine();
	while(list.contains(quizid))
	{		
		System.out.println("This id is already present");
		System.out.println("--------Enter another QuizId:");
		quizid=in.nextLine();
	}
	qb.setQuizId(quizid);
	
	int no=0;
	boolean ex=false;
	while(ex==false){
	try{
		System.out.println("--------Enter No. of questions:");
	no=Integer.parseInt(in.nextLine());
	qb.setNoOfQuestions(no);
	ex=true;
	}
	catch(NumberFormatException e)
	{
		System.out.println("Number Format is not followed ");
		
	}
	}
	boolean ex2=false;
	while(ex2==false){
	try{
		
	System.out.println("--------Enter Maximum score:");
	qb.setMaxScore(Integer.parseInt(in.nextLine()));
	ex2=true;
	}
	catch(NumberFormatException e)
	{
		System.out.println("Number Format is not followed ");
		
	}
	}
	QuizContentBean[] qContent=new QuizContentBean[no];
	
	System.out.println("--------Enter Quiz Content:");
    for(int i=0;i<no;i++)
    {
    	System.out.println("--------Question "+(i+1)+":");
    	String ques=in.nextLine();
    	System.out.println("--------enter 4 Choices");
    	String cans[]=new String[4];
    	for(int j=0;j<4;j++)
    	{
    	   cans[j]=in.nextLine();
    	}
    	System.out.println("--------answer:");
    	String ans=in.nextLine();
    	System.out.println("--------weightage:");
    	int w=Integer.parseInt(in.nextLine());
    	System.out.println(ques);
    	qContent[i]=new QuizContentBean();
    	qContent[i].setQuestion(ques);
    	qContent[i].setAnswer(ans);
    	qContent[i].setChoiceList(cans);
    	qContent[i].setWeightage(w);
    	qContent[i].setQuizID(quizid);
    	//qcd.insertQuizContent(qContent[i]);
    	
    }
    qb.setQuizContentBean(qContent);
   
    int res=qd.insertQuiz(qb);
    if(res==1)
    	  System.out.println("Quiz added");
    else
    	
    	  System.out.println("Failed to add quiz");
	
    
	}
}
