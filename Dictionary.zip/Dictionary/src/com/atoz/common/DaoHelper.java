package com.atoz.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DaoHelper {
	
	public static Connection getConnection()
	{
		//System.out.println("Insode Connection");
		try{
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			}
			catch(ClassNotFoundException e )
			{
				e.printStackTrace();
			}
			Connection conn=null;
			try{
				
		    //Create connection object
		        //conn=DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");
				conn=DriverManager.getConnection("jdbc:derby://172.24.21.24:1527/DictionaryDB","Janani","jananidb");
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
			return conn;
	}
	

}
