package com.atoz.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;



public class WordApp {
	
	@Autowired
	static WordDao uwordDao;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int choice;
		Scanner in=new Scanner(System.in);
		System.out.println("0.Insert Word Objects from a file");
		System.out.println("1.Insert a Word Object");
		System.out.println("2.Delete a Word Object");
		System.out.println("3.Update meaning of a  Word Object");
		System.out.println("4.Update type of a  Word Object");
		System.out.println("5.Update frequency of a  Word Object");
		System.out.println("6.Display details of a Word Object");
		System.out.println("7.Display details of Word Objects starting with characters __ ");
		System.out.println("8.Display all Word Objects");
		System.out.println("9.Get count of all words");
		System.out.println("10.Get count of words starting with characters __");
		System.out.println("11.Delete Word Objects starting with characters __ ");
		System.out.println("12.Exit");
		System.out.println("Enter your choice:");
		WordDao wordDao = new WordDao();
		//wordDao.insertWordFromFile();
		//System.out.println("Enter your choice:");
		choice=in.nextInt();
		in.nextLine();
		
		while(choice!=12)
		{
		switch(choice)
		{
		case 0:
			System.out.println("Ensure format --> word (type) meaning in each line");
			int res=wordDao.insertWordFromFile();
			System.out.println("Successfully Inserted "+res+"words..");
			break;
		case 1:
			
			WordBean wBean=new WordBean();
			System.out.println("Enter word:");
			String word=in.nextLine();
			System.out.println("Enter type:");
			String type=in.nextLine();
			System.out.println("Enter meaning:");
			String meaning=in.nextLine();
			wBean.setWord(word);
			wBean.setType(type);
			wBean.setMeaning(meaning);
			wBean.setFrequency(0);
			Map<Character,Integer> allCount=wordDao.getCountOfRows();
			wBean.setId(allCount.get('-'));
			int result=wordDao.insertWord(wBean);
			if(result==1)
				System.out.println("Successfully Inserted..");
			else
				System.out.println("Failed to  Insert!!");
			break;
	
		case 2:
			System.out.println("Enter word to Delete:");
			String wordDelete=in.nextLine();
			int dResult=wordDao.deleteWord(wordDelete);
			if(dResult==1)
				System.out.println("Successfully Deleted..");
			else
				System.out.println("Failed:No such word to delete!!");
			
			break;
	
		case 3:
			System.out.println("Enter word's id to Update:");
			int wordId=Integer.parseInt(in.nextLine());
			System.out.println("Enter word to Update:");
			String wordUpdate=in.nextLine();
			System.out.println("Enter meaning to Update:");
			String meaningUpdate=in.nextLine();
			if(uwordDao==null)
				System.out.println();
			int uResult=uwordDao.updateMeaning(wordId,wordUpdate,meaningUpdate);
			if(uResult==1)
				System.out.println("Successfully Updated..");
			else
				System.out.println("Failed:No such word to Update!!");
			
			break;
		case 4:
			System.out.println("Enter word's id to Update:");
			int wordId2=Integer.parseInt(in.nextLine());
			System.out.println("Enter word to Update:");
			String wUpdate=in.nextLine();
			System.out.println("Enter  type to Update:");
			String typeUpdate=in.nextLine();
			int upResult=wordDao.updateType(wordId2,wUpdate,typeUpdate);
			if(upResult==1)
				System.out.println("Successfully Updated..");
			else
				System.out.println("Failed:No such word to Update!!");
		    break;
		case 5:
			System.out.println("Enter word's id to Update:");
			int wordId3=Integer.parseInt(in.nextLine());
			System.out.println("Enter word to Update:");
			String wFUpdate=in.nextLine();
			System.out.println("Enter  frequency to Update:");
			int fUpdate=in.nextInt();
			int uFResult=wordDao.updateFrequency(wordId3,wFUpdate,fUpdate);
			if(uFResult==1)
				System.out.println("Successfully Updated..");
			else
				System.out.println("Failed:No such word to Update!!");
		    break;
		case 6:
			System.out.println("Enter word to Search:");
			String wSearch=in.nextLine();
			List<WordBean> wordList = wordDao.getWord(wSearch);
			if(wordList!=null)
			{
				
			System.out.println("Retrieved: "+wordList.size()+" objects");
			Iterator<WordBean> itr =  wordList.iterator();
			while(itr.hasNext()){
				WordBean wordBean = itr.next();
				System.out.println("word: "+wordBean.getWord()+ "; meaning: "+ wordBean.getMeaning()+ "; type: "+ wordBean.getType()+ ";");
				
			}
			}
			else				
			   System.out.println("Failed to Retrieve..");
			break;
			
		case 7:
			String c;
			System.out.println("enter the characters as a string");
			c=in.nextLine();
List<WordBean> wordList1= wordDao.getWords(c.toCharArray());
			
			if(wordList1!=null)
			{
				Collections.sort(wordList1,new FrequencyComparator());
			System.out.println("Retrieved: "+wordList1.size()+" objects");
			Iterator<WordBean> itr =  wordList1.iterator();
			while(itr.hasNext()){
				WordBean wordBean = itr.next();
				System.out.println("word: "+wordBean.getWord()+ "; meaning: "+ wordBean.getMeaning()+ "; type: "+ wordBean.getType()+ "; frequency: "+ wordBean.getFrequency());
				
			}
			}
			else				
			   System.out.println("Failed to Retrieve..");
			break;
			
		case 8:
			List<WordBean> wordList2= wordDao.getWords();
			
			if(wordList2!=null)
			{
				Collections.sort(wordList2,new FrequencyComparator());
			System.out.println("Retrieved: "+wordList2.size()+" objects");
			Iterator<WordBean> itr =  wordList2.iterator();
			while(itr.hasNext()){
				WordBean wordBean = itr.next();
				System.out.println("word: "+wordBean.getWord()+ "; meaning: "+ wordBean.getMeaning()+ "; type: "+ wordBean.getType()+ "; frequency: "+ wordBean.getFrequency());
				
			}
			}
			else				
			   System.out.println("Failed to Retrieve..");
			break;
		case 9:
			System.out.println("Count: "+wordDao.getCountOfRows().get('-'));
			break;
		case 10:
			String ch;
			System.out.println("enter the characters as a string");
			ch=in.nextLine();
			 Map<Character,Integer> charCount=wordDao.getCountOfRows(ch.toCharArray());
			 
			 for(Map.Entry me:charCount.entrySet())
			 {
				 System.out.println(me.getKey()+ " -- "+me.getValue()+"words");
			 }
			
			break;
		case 11:
			String chr;
			System.out.println("enter the characters as a string");
			chr=in.nextLine();
			int r=wordDao.deleteWords(chr.toCharArray());
			if(r==1)
			System.out.println("Successfully Deleted..");
			else
				System.out.println("Failed:No such word to delete!!");
			break;
	   default:
		   
		   System.out.println("Invalid Option");
		   break;
			
		
		}
		System.out.println("0.Insert Word Objects from a file");
		System.out.println("1.Insert a Word Object");
		System.out.println("2.Delete a Word Object");
		System.out.println("3.Update meaning of a  Word Object");
		System.out.println("4.Update type of a  Word Object");
		System.out.println("5.Update frequency of a  Word Object");
		System.out.println("6.Display details of a Word Object");
		System.out.println("7.Display details of Word Objects starting with characters __ ");
		System.out.println("8.Display all Word Objects");
		System.out.println("9.Get count of all words");
		System.out.println("10.Get count of words starting with characters __");
		System.out.println("11.Delete Word Objects starting with characters __ ");
		System.out.println("12.Exit");
		System.out.println("Enter your choice:");
		choice=in.nextInt();
		in.nextLine();
		}
	}

}

