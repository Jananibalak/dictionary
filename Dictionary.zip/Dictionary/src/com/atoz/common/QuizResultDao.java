package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class QuizResultDao {
	
	public int insertReport(QuizResultBean qrb)
	{

		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		QuizReportDao qrd=new  QuizReportDao ();
		QuizReportBean qrbean=new QuizReportBean();
		try {
			 stmt = conn.createStatement();

			 int lBest=bestOfAttempts(qrb.getEmailId(),qrb.getQuizId());
		        
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/
			 
			  String query="INSERT INTO T_XBBNHBG_QUIZRESULT VALUES('"+qrb.getEmailId()+"','"+qrb.getQuizId()+"','"+qrb.getTimeOfAttempt()+"',"+qrb.getNoOfQuestions()+","+qrb.getNoOfattempted()+","+qrb.getNoOfcorrect()+","+qrb.getScore()+")";
		        int r=stmt.executeUpdate(query);
		        int nBest=bestOfAttempts(qrb.getEmailId(),qrb.getQuizId());
		         
		       int totalScore=qrd.calcTotal(qrb.getEmailId(),lBest,nBest);
		       qrbean.setEmailId(qrb.getEmailId());
		       qrbean.setRecentScore(qrb.getScore());
		       qrbean.setTotalScore(totalScore);
		       int noOfQuiz=getNoOfQuiz(qrb.getEmailId());
		       qrbean.setNoOfQuiz(noOfQuiz);
		      int r1=qrd.insertReport(qrbean);
		        if(r==1&&r1==1)
		        	return 1;
		        else
		        	return 0;
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return 0;
		
	}
	public int bestOfAttempts(String emailId,String quizId)
	{
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		  int best=0;
		try {
			 stmt = conn.createStatement();

				
		        
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/
			  String query="select max(score) from T_XBBNHBG_QUIZRESULT where emailid='"+emailId+"' and quizid='"+quizId+"'";
		        ResultSet r=stmt.executeQuery(query);
		   
		       while(r.next())
		       {
		    	   best=r.getInt(1);
		       }
		       
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return best;
	}
	public int getNoOfQuiz(String emailId)
	{
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		  int noOfQuiz=0;
		try {
			 stmt = conn.createStatement();

				
		        
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/
			  String query="select count(distinct quizid) from T_XBBNHBG_QUIZRESULT where emailid='"+emailId+"' group by emailid";
		        ResultSet r=stmt.executeQuery(query);
		   
		       while(r.next())
		       {
		    	   noOfQuiz=r.getInt(1);
		       }
		       
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return  noOfQuiz;
	}
    
	public List<QuizResultBean> retrieveResults(String emailId)
	{
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		  int noOfQuiz=0;

			 List<QuizResultBean> qr=new ArrayList<QuizResultBean> ();
		   
		try {
			 stmt = conn.createStatement();
     
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/
			  String query="select * from T_XBBNHBG_QUIZRESULT where emailid='"+emailId+"'";
		        ResultSet r=stmt.executeQuery(query);
		   
		       while(r.next())
		       {
		    	   QuizResultBean qrb=new QuizResultBean();
		    	   qrb.setNoOfQuestions(r.getInt(4));
		    	   qrb.setNoOfattempted(r.getInt(5));
		    	   qrb.setNoOfcorrect(r.getInt(6));
		    	   qrb.setQuizId(r.getString(2));
		    	   qrb.setScore(r.getInt(7));
		    	   qrb.setTimeOfAttempt((r.getString(3)));
		    	   qr.add(qrb);
		       }
		       
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return  qr;
	}
}
