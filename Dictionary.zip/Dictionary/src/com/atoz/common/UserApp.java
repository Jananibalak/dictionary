package com.atoz.common;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class UserApp {
	static String emailId="";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		int choice;
		Scanner in=new Scanner(System.in);
		System.out.println("0.Sign Up");
		System.out.println("1.Login");
		System.out.println("2.My Search History for a word");
		System.out.println("3.Display Words starting with character _");
		System.out.println("4.Attend Quiz");
		System.out.println("5.My Rank");
		System.out.println("6.Total Score");
		System.out.println("7.Quiz Results");
		//System.out.println("6.Best Score");
		//System.out.println("7.Quiz Report");
		System.out.println("8.Exit");
		System.out.println("Enter your choice:");
		UserDao userDao = new UserDao();
		//wordDao.insertWordFromFile();
		//System.out.println("Enter your choice:");
		choice=in.nextInt();
		in.nextLine();
		
		while(choice!=8)
		{
		switch(choice)
		{
		case 0:
			System.out.println("Give your Details for the signUp process");
			UserBean uBean=new UserBean();
			System.out.println("Enter EmailId:");
			String eid=in.nextLine();
			System.out.println("Enter Password:");
			String pwd=in.nextLine();
			System.out.println("Enter Name:");
			String name=in.nextLine();
			System.out.println("Enter Country:");
			String country=in.nextLine();
			uBean.setEmailId(eid);
			uBean.setPassword(pwd);
			uBean.setName(name);
			uBean.setCountry(country);
			
			int res=userDao.signUp(uBean);
			if(res==1){
			System.out.println("Welcome..");
			emailId=uBean.getEmailId();
			}
			else if(res==-1)
			{
				System.out.println("Your EmailId is already registered..");
			}
			else
				System.out.println("SignUp Failed..");
			break;
		case 1:
			WordBean wBean=new WordBean();
			System.out.println("Give your Details for the Login process");
			
			System.out.println("Enter EmailId:");
			String emid=in.nextLine();
			System.out.println("Enter Password:");
			String pawd=in.nextLine();
			int result=userDao.login(emid, pawd);
			if(result==1){
				System.out.println("Welcome..");
				emailId=emid;
			}
			else
				System.out.println("Invalid Details!!");
			break;
	
		case 2:
			if(emailId!=""){
			System.out.println("Enter word to Search:");
			String wSearch=in.nextLine();
			WordDao wordDao=new WordDao();
			List<WordBean> wordList = wordDao.getWord(wSearch);
			if(wordList!=null)
			{
				
			System.out.println("Retrieved: "+wordList.size()+" objects");
			Iterator<WordBean> itr =  wordList.iterator();
			while(itr.hasNext()){
				WordBean wordBean = itr.next();
				System.out.println("word: "+wordBean.getWord()+ "; meaning: "+ wordBean.getMeaning()+ "; type: "+ wordBean.getType()+ ";");
				
			}
			}
			else				
			   System.out.println("Failed to Retrieve..");
			
			}
			else
			{
				System.out.println("Please do login or signUp");
			}
			break;
			
		case 3:
			if(emailId!=""){
			System.out.println("Enter starting character:");
			char charSearch=in.nextLine().charAt(0);
			WordDao wordDao1=new WordDao();
            List<WordBean> wordList1= wordDao1.getWords(charSearch);
			
			if(wordList1!=null)
			{
				Collections.sort(wordList1,new FrequencyComparator());
			System.out.println("Retrieved: "+wordList1.size()+" objects");
			Iterator<WordBean> itr =  wordList1.iterator();
			while(itr.hasNext()){
				WordBean wordBean = itr.next();
				System.out.println("word: "+wordBean.getWord()+ "; meaning: "+ wordBean.getMeaning()+ "; type: "+ wordBean.getType()+ "; frequency: "+ wordBean.getFrequency());
				
			}
			}
			else				
			   System.out.println("Failed to Retrieve..");
		}
		else
		{
			System.out.println("Please do login or signUp");
		}
			
			break;
		case 4:
			if(!emailId.isEmpty()){
				 QuizDao qd=new QuizDao();
					List<String> list=qd.listQuiz();
					System.out.println("Available QuizId");
					int l=0;
					for(String qi:list)
					{
						System.out.println(l+1+") "+qi);
						l=l+1;
					}
			System.out.println("Enter quizId:");
			String qid=in.nextLine();
			if(list.contains(qid)){
			int score=0;
			int noOfQuestions;
			int noOfattempted=0;
			int noOfcorrect=0;
			QuizContentDao qcDao=new QuizContentDao();
			List<QuizContentBean> qcbList=qcDao.retrieveContent(qid);
			noOfQuestions=qcbList.size();
			for(QuizContentBean e:qcbList)
			{
				System.out.println("----Question");
				System.out.println(e.getQuestion());
				System.out.println("---Choices");
				for(int i=0;i<e.getChoiceList().length;i++)
				{
				System.out.println(e.getChoiceList()[i]+" ");
				}
				System.out.println("your answer");
				String answer=in.nextLine();
				if(answer!="-")
				{
					noOfattempted+=1;
				}
				if(answer.equals(e.getAnswer())){
					System.out.println("Good :-)");
					score+=e.getWeightage();
					noOfcorrect+=1;
				}
				else
					System.out.println("The Correct answer is "+e.getAnswer()+" :-(");
				
			}
			System.out.println("---Score:"+score);
			QuizResultBean qrBean=new QuizResultBean();
			qrBean.setEmailId(emailId);
			qrBean.setQuizId(qid);
			qrBean.setNoOfQuestions(noOfQuestions);
			qrBean.setScore(score);
			qrBean.setNoOfattempted(noOfattempted);
			qrBean.setNoOfcorrect(noOfcorrect);
			String timeOfAttempt=new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
			qrBean.setTimeOfAttempt(timeOfAttempt);
			QuizResultDao QRDao=new QuizResultDao();
			QRDao.insertReport(qrBean);
			System.out.println("youe best Score in this quiz:"+QRDao.bestOfAttempts(emailId, qid));
			}
			else
			{
				System.out.println("No such quizId");
			}
			}
			else
			{
				System.out.println("Please do login or signUp");
			}
				
		    break;
		case 5:
			if(!emailId.isEmpty()){
			QuizReportDao qrd=new QuizReportDao();
			
			   System.out.println("Your rank : "+qrd.calcRank(emailId));
			}
			else
			{
				System.out.println("Please do login or signUp");
			}
		    break;
		case 6:
			
			if(!emailId.isEmpty()){
				QuizReportDao qrd=new QuizReportDao();
				
				   System.out.println("Your total Score : "+qrd.getTotalScore(emailId));
				}
				else
				{
					System.out.println("Please do login or signUp");
				}
			    break;
		case 7:
			if(!emailId.isEmpty()){
				QuizResultDao qrd=new QuizResultDao();
				
				   List<QuizResultBean> list=qrd.retrieveResults(emailId);
				   for(QuizResultBean qrb:list)
				   {
					   System.out.println("QuizId:"+qrb.getQuizId());
					   System.out.println("Time of attempt:"+qrb.getTimeOfAttempt());
					   System.out.println("no of questions:"+qrb.getNoOfQuestions());
					   System.out.println("no of attempted:"+qrb.getNoOfattempted());
					   System.out.println("no of correct:"+qrb.getNoOfcorrect());
					   System.out.println("score:"+qrb.getScore());
					
					   
					   
					   
				   }
				   
				}
				else
				{
					System.out.println("Please do login or signUp");
				}
			    break;
	
	   default:
		   
		   System.out.println("Invalid Option");
		   break;
			
		
		}
		System.out.println("0.Sign Up");
		System.out.println("1.Login");
		System.out.println("2.My Search History for a word");
		System.out.println("3.Display Words starting with character _");
		System.out.println("4.Attend Quiz");
		System.out.println("5.My Rank");
		System.out.println("6.Total Score");
		//System.out.println("6.Best Score");
		System.out.println("7.Quiz Results");
		System.out.println("8.Exit");
		System.out.println("Enter your choice:");
		choice=in.nextInt();
		in.nextLine();
		}
	

}
}
