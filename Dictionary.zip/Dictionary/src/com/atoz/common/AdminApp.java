package com.atoz.common;

import java.util.List;
import java.util.Scanner;

public class AdminApp {

	static String access="no";
	public static void main(String args[])
	{
		Scanner in=new Scanner(System.in);
		System.out.println("1.Login");
		System.out.println("2.Handle Quiz");
		System.out.println("3.Handle Words");
		System.out.println("4.Quiz Report");
		System.out.println("5.Exit");
		int ch;

		AdminDao aDao=new AdminDao ();
		System.out.println("Enter choice");
		ch=Integer.parseInt(in.nextLine());
		do
		{
			
			
			switch(ch)
			{
			case 1:
				System.out.println("Enter password");
				String pwd=in.nextLine();
				if(aDao.checkAdmin(pwd)==1){
					access="yes";
					System.out.println("Welcome;");
				}
				else
				{
					System.out.println("Invalid details");
				}
				break;
			case 2:
				if(access.equals("yes"))
				QuizApp.main(args);
				else
					System.out.println("please do login");
				break;
			case 3:
				if(access.equals("yes"))
				WordApp.main(args);
				else
					System.out.println("please do login");
				break;
			case 4:
				if(access.equals("yes")){
					List<QuizReportBean> list=aDao.retrieveReport();
					System.out.println("--EmailId--Name--\t--TotalScore--\t--Rank--");
					for(QuizReportBean qrb:list)
					{
						System.out.println(qrb.getEmailId()+"\t"+qrb.getTotalScore()+"\t"+qrb.getRank());
					}
				}
				else
					System.out.println("please do login");
				break;
				default:
					System.out.println("Invalid Option");
					break;
				
			
			}
			System.out.println("Enter choice");
			ch=Integer.parseInt(in.nextLine());
		
		}while(ch!=5);
	}
}
