package com.atoz.common;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class IDWRowMapper implements RowMapper<WordBean> {

	@Override
	public WordBean mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		WordBean wb=new WordBean();
		wb.setId(rs.getInt(5));
		wb.setFrequency(rs.getInt(4));
		wb.setMeaning(rs.getString(3));
		wb.setType(rs.getString(2));
		wb.setWord(rs.getString(1));
		
		return wb;
	}

}
