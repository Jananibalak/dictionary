package com.atoz.common;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
public class IDRowMapper implements RowMapper<String> {

	@Override
	public String mapRow(ResultSet rs, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println(rs.getFetchSize()+"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		return rs.getString(1);
	}

}
