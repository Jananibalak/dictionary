package com.atoz.common;

public class QuizBean {
            String quizId;
            int maxScore;
            QuizContentBean[] quizContentBean;
            int noOfQuestions;
			public int getNoOfQuestions() {
				return noOfQuestions;
			}
			public void setNoOfQuestions(int noOfQuestions) {
				this.noOfQuestions = noOfQuestions;
			}
			public String getQuizId() {
				return quizId;
			}
			public void setQuizId(String quizId) {
				this.quizId = quizId;
			}
			public int getMaxScore() {
				return maxScore;
			}
			
			public QuizContentBean[] getQuizContentBean() {
				return quizContentBean;
			}
			public void setQuizContentBean(QuizContentBean[] quizContentBean) {
				this.quizContentBean = quizContentBean;
			}
			public void setMaxScore(int maxScore) {
				this.maxScore = maxScore;
			}
            
}
