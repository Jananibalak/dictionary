package com.atoz.common;

public class QuizResultBean {
	
	String emailId;
	String quizId;
	int noOfQuestions;
	int noOfattempted;
	int noOfcorrect;
	int score;
	String TimeOfAttempt;
	public String getTimeOfAttempt() {
		return TimeOfAttempt;
	}
	public void setTimeOfAttempt(String timeOfAttempt) {
		TimeOfAttempt = timeOfAttempt;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getQuizId() {
		return quizId;
	}
	public void setQuizId(String quizId) {
		this.quizId = quizId;
	}
	public int getNoOfQuestions() {
		return noOfQuestions;
	}
	public void setNoOfQuestions(int noOfQuestions) {
		this.noOfQuestions = noOfQuestions;
	}
	public int getNoOfattempted() {
		return noOfattempted;
	}
	public void setNoOfattempted(int noOfattempted) {
		this.noOfattempted = noOfattempted;
	}
	public int getNoOfcorrect() {
		return noOfcorrect;
	}
	public void setNoOfcorrect(int noOfcorrect) {
		this.noOfcorrect = noOfcorrect;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	

}
