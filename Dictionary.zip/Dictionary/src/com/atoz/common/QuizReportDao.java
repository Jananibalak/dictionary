package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class QuizReportDao {

	 public int calcTotal(String emailId,int lBest,int nBest)
	 {
		 int addtScore;
		 if(lBest==nBest)
		 {
			 addtScore=0;
		 }
		 else
		 {
			 addtScore=nBest-lBest;
		 }

			Connection conn = DaoHelper.getConnection();
			Statement stmt = null;
			
			  int tscore=0;
				try {
					 stmt = conn.createStatement();

						
				        
				       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
				       /*derby*/
					  String query="select totalscore from T_XBBNHBG_QUIZREPORT where emailid='"+emailId+"'";
				        ResultSet r=stmt.executeQuery(query);
				   
				       while(r.next())
				       {
				    	   tscore=r.getInt(1);
				       }
				       tscore+=addtScore;
				       
					    
				} 
				catch(SQLSyntaxErrorException ex)
				{
					ex.printStackTrace();
				}catch (SQLException e) {
					
					e.printStackTrace();
				}		
				
				finally{
					
					try {
						
						if(conn!=null)
							conn.close();
						if(stmt!=null)
							stmt.close();
									
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				
			     return tscore;
	 }
	 public int calcRank(String emailId)
	 {
		
			Connection conn = DaoHelper.getConnection();
			Statement stmt = null;
			
			  int rank=0;
				try {
					 stmt = conn.createStatement();

						
				        
				       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
				       /*derby*/
					  String query="select emailId from T_XBBNHBG_QUIZREPORT order by totalscore desc";
				        ResultSet r=stmt.executeQuery(query);
				   
				       while(r.next())
				       {
				    	  
				    	  rank++;   
				    	  if(r.getString(1).equals(emailId))
				    	  {
				    		  break;
				    	  }
				       }
				   
				       
					    
				} 
				catch(SQLSyntaxErrorException ex)
				{
					ex.printStackTrace();
				}catch (SQLException e) {
					
					e.printStackTrace();
				}		
				
				finally{
					
					try {
						
						if(conn!=null)
							conn.close();
						if(stmt!=null)
							stmt.close();
									
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				
			     return rank;
	 }
	 
	 public int insertReport(QuizReportBean qrb)
		{

			Connection conn = DaoHelper.getConnection();
			Statement stmt = null;
			QuizReportDao qrd=new  QuizReportDao ();
			
			try {
				 stmt = conn.createStatement();
                  if(check(qrb.getEmailId())==0){
				  String query="INSERT INTO T_XBBNHBG_QUIZREPORT(EMAILID,TOTALSCORE,BESTSCORE,NOOFQUIZ) VALUES('"+qrb.getEmailId()+"',"+qrb.getTotalScore()+","+qrb.getRecentScore()+","+qrb.getNoOfQuiz()+")";
			        int r=stmt.executeUpdate(query);
			       
			       int rank=qrd.calcRank(qrb.getEmailId());
			       String query1="update T_XBBNHBG_QUIZREPORT set rank="+rank+" where emailId='"+qrb.getEmailId()+"'";
			       int r1=stmt.executeUpdate(query1);
			        if(r==1&&r1==1)
			        	return 1;
			        else
			        	return 0;
                  }
                  else
                  {
                	  int rank=qrd.calcRank(qrb.getEmailId());
                	   String query1="update T_XBBNHBG_QUIZREPORT set rank="+rank+",totalscore="+qrb.getTotalScore()+",bestScore="+qrb.getRecentScore()+",noofquiz="+qrb.getNoOfQuiz()+" where emailId='"+qrb.getEmailId()+"'";
    			       int r1=stmt.executeUpdate(query1);
    			       if(r1==1)
   			        	return 1;
   			        else
   			        	return 0;
                  }
				    
			} 
			catch(SQLSyntaxErrorException ex)
			{
				ex.printStackTrace();
			}catch (SQLException e) {
				
				e.printStackTrace();
			}		
			
			finally{
				
				try {
					
					if(conn!=null)
						conn.close();
					if(stmt!=null)
						stmt.close();
								
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			
		     return 0;
			
		}
	 int check(String emailid)
	 {
		 Connection conn = DaoHelper.getConnection();
			Statement stmt = null;
			
			  int rank=0;
				try {
					 stmt = conn.createStatement();

						
				        
				       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
				       /*derby*/
					  String query="select count(*) from T_XBBNHBG_QUIZREPORT where emailId='"+emailid+"'";
				        ResultSet r=stmt.executeQuery(query);
				   
				       while(r.next())
				       {
				    	  
				    	  
				    	  if(r.getInt(1)>0)
				    	  {
				    		  return 1;
				    	  }
				       }
				   
				       
					    
				} 
				catch(SQLSyntaxErrorException ex)
				{
					ex.printStackTrace();
				}catch (SQLException e) {
					
					e.printStackTrace();
				}		
				
				finally{
					
					try {
						
						if(conn!=null)
							conn.close();
						if(stmt!=null)
							stmt.close();
									
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				
			     return 0;
	 }
	 public int getTotalScore(String emailid)
	 {
		 Connection conn = DaoHelper.getConnection();
			Statement stmt = null;
			
			  int rank=0;
				try {
					 stmt = conn.createStatement();

						
				        
				       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
				       /*derby*/
					  String query="select totalscore from T_XBBNHBG_QUIZREPORT where emailId='"+emailid+"'";
				        ResultSet r=stmt.executeQuery(query);
				   
				       while(r.next())
				       {
				    	  
				    	  
				    	  return r.getInt(1);
				       }
				   
				       
					    
				} 
				catch(SQLSyntaxErrorException ex)
				{
					ex.printStackTrace();
				}catch (SQLException e) {
					
					e.printStackTrace();
				}		
				
				finally{
					
					try {
						
						if(conn!=null)
							conn.close();
						if(stmt!=null)
							stmt.close();
									
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				
			     return 0;
	 }
	 public int getRecentScore(String emailid)
	 {
		 Connection conn = DaoHelper.getConnection();
			Statement stmt = null;
			
			  int rank=0;
				try {
					 stmt = conn.createStatement();

						
				        
				       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
				       /*derby*/
					  String query="select bestscore from T_XBBNHBG_QUIZREPORT where emailId='"+emailid+"'";
				        ResultSet r=stmt.executeQuery(query);
				   
				       while(r.next())
				       {
				    	  
				    	  
				    	  return r.getInt(1);
				       }
				   
				       
					    
				} 
				catch(SQLSyntaxErrorException ex)
				{
					ex.printStackTrace();
				}catch (SQLException e) {
					
					e.printStackTrace();
				}		
				
				finally{
					
					try {
						
						if(conn!=null)
							conn.close();
						if(stmt!=null)
							stmt.close();
									
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				
			     return 0;
	 }
	 public List<QuizReportBean> getLBoard()
	 {
		

			Connection conn = DaoHelper.getConnection();
			Statement stmt = null;
			List<QuizReportBean> rList=new ArrayList<QuizReportBean>();
			  
				try {
					 stmt = conn.createStatement();

						
				        
				       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
				       /*derby*/
					  String query="select * from T_XBBNHBG_QUIZREPORT order by rank";
				        ResultSet r=stmt.executeQuery(query);
				   
				       while(r.next())
				       {
				    	   QuizReportBean qrb=new QuizReportBean();
				    	   qrb.setEmailId(r.getString(1));
				    	   qrb.setTotalScore(Integer.parseInt(r.getString(2)));
				    	   qrb.setRecentScore(Integer.parseInt(r.getString(3)));
				    	   qrb.setNoOfQuiz(Integer.parseInt(r.getString(4)));
				    	   qrb.setRank(Integer.parseInt(r.getString(5)));
				    	   rList.add(qrb);
				    	   
				       }
				       
				       
					    
				} 
				catch(SQLSyntaxErrorException ex)
				{
					ex.printStackTrace();
				}catch (SQLException e) {
					
					e.printStackTrace();
				}		
				
				finally{
					
					try {
						
						if(conn!=null)
							conn.close();
						if(stmt!=null)
							stmt.close();
									
						
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

				
			     return rList;
	 }
	 
}
