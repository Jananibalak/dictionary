package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class QuizDao {
	public int insertQuiz(QuizBean quiz)
	{

		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		QuizReportDao qrd=new  QuizReportDao ();
		
		try {
			 stmt = conn.createStatement();

			  String query="INSERT INTO T_XBBNHBG_QUIZ VALUES('"+quiz.getQuizId()+"',"+quiz.getNoOfQuestions()+","+quiz.getMaxScore()+")";
		        int r=stmt.executeUpdate(query);
		        QuizContentBean[] qcontent=quiz.getQuizContentBean();
		        QuizContentDao qcd=new QuizContentDao ();
		        for(int i=0;i<qcontent.length;i++)
		        {
		        	qcd.insertQuizContent(qcontent[i]);
		        }
		        
		        if(r==1)
		        	return 1;
		        else
		        	return 0;
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return 0;
	}
	public int deleteQuiz(String quizid)
	{

		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		QuizReportDao qrd=new  QuizReportDao ();
		
		try {
			 stmt = conn.createStatement();
			   String query1="delete from T_XBBNHBG_QUIZCONTENT where quizid='"+quizid+"'";
		        int r1=stmt.executeUpdate(query1);
			  String query="delete from T_XBBNHBG_QUIZ where quizid='"+quizid+"'";
		        int r=stmt.executeUpdate(query);
		     
		        if(r==1&&r1==1)
		        	return 1;
		        else
		        	return 0;
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return 0;
	}
	public List<String> listQuiz()
	{
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		QuizReportDao qrd=new  QuizReportDao ();
		List<String> li=new ArrayList<String>();
		try {
			 stmt = conn.createStatement();

			  String query="select quizid from T_XBBNHBG_QUIZ";
		        ResultSet rs=stmt.executeQuery(query);
		         while(rs.next())
		         {
		        	 li.add(rs.getString(1));
		         }
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return li;
	}
	
}
