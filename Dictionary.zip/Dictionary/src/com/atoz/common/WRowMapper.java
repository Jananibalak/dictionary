package com.atoz.common;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.RowMapper;



public class WRowMapper implements RowMapper{

	@Override
	
		// TODO Auto-generated method stub
		public List<WordBean> mapRow(ResultSet resultset, int arg1) throws SQLException {
			// TODO Auto-generated method stub
		
		 List<WordBean> l=new ArrayList<WordBean>();
		 
		 if(resultset!=null)
			{
			do{
				System.out.println("janani");
				String word=resultset.getString(1);
				WordBean wordBean = new WordBean();
				wordBean.setType(resultset.getString(2));
				wordBean.setMeaning(resultset.getString(3));
				wordBean.setFrequency(Integer.parseInt(resultset.getString(4)));
				
				wordBean.setId(Integer.parseInt(resultset.getString(5)));
				
				wordBean.setWord(word);
				

			l.add(wordBean);
			}while(resultset.next());}
			return l;
		}
	
}
