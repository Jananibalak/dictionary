package com.atoz.common;

import java.util.Comparator;

public class FrequencyComparator<WordBean> implements Comparator<WordBean>{  
public int compare(WordBean w1,WordBean w2){  

if( ((com.atoz.common.WordBean) w1).getFrequency()==((com.atoz.common.WordBean) w2).getFrequency())  
return 0;  
else if(((com.atoz.common.WordBean) w1).getFrequency()<((com.atoz.common.WordBean) w2).getFrequency())  
return 1;  
else  
return -1;  
}  
} 