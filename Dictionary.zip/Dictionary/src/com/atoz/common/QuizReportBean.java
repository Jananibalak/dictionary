package com.atoz.common;

public class QuizReportBean {
	
	
	String emailId;
	int totalScore;
	int RecentScore;
	int noOfQuiz;
	int rank;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	int getNoOfQuiz() {
		return noOfQuiz;
	}
	
	public int getRecentScore() {
		return RecentScore;
	}
	public void setRecentScore(int recentScore) {
		RecentScore = recentScore;
	}
	public void setNoOfQuiz(int noOfQuiz) {
		this.noOfQuiz = noOfQuiz;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	

}
