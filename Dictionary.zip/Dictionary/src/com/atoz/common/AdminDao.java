package com.atoz.common;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLSyntaxErrorException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AdminDao {

	public int checkAdmin(String pwd)
	{
		if(pwd.equals("abc123"))
			return 1;
		else
			return -1;
	}
	public List<QuizReportBean> retrieveReport()
	{
		
		Connection conn = DaoHelper.getConnection();
		Statement stmt = null;
		  int noOfQuiz=0;

			 List<QuizReportBean> qr=new ArrayList<QuizReportBean> ();
		   
		try {
			 stmt = conn.createStatement();
     
		       /*oracle*/// String query="INSERT INTO T_XBBNHBG_WORDS VALUES('"+word+"','"+type+"','"+meaning+"',"+frequency+","+wordBean.getId()+")";
		       /*derby*/
			  String query="select EMAILID,NAME,NOOFQUIZ,BESTSCORE,TOTALSCORE,Rank from T_XBBNHBG_QUIZREPORT NATURAL JOIN  T_XBBNHBG_USER";
		        ResultSet r=stmt.executeQuery(query);
		   
		       while(r.next())
		       {
		    	   QuizReportBean qrb=new QuizReportBean();
		    	   qrb.setEmailId(r.getString(1)+"--"+r.getString(2));
		    	   qrb.setNoOfQuiz(r.getInt(3));
		    	   qrb.setRecentScore(r.getInt(4));
		    	   qrb.setTotalScore(r.getInt(5));
		    	   qrb.setRank(r.getInt(6));
		    	   qr.add(qrb);
		       }
		       
			    
		} 
		catch(SQLSyntaxErrorException ex)
		{
			ex.printStackTrace();
		}catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
		finally{
			
			try {
				
				if(conn!=null)
					conn.close();
				if(stmt!=null)
					stmt.close();
							
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		
	     return  qr;
	}
}
