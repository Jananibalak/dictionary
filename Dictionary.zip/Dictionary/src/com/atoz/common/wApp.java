package com.atoz.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;



public class wApp {
	
	@Autowired
	static WordDao uwordDao;
	public void createApp()
	{
		wApp w=new wApp();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner in=new Scanner(System.in);
	
			System.out.println("Enter word's id to Update:");
			int wordId=Integer.parseInt(in.nextLine());
			System.out.println("Enter word to Update:");
			String wordUpdate=in.nextLine();
			System.out.println("Enter meaning to Update:");
			String meaningUpdate=in.nextLine();
			if(uwordDao==null)
				System.out.println("nullll");
			int uResult=uwordDao.updateMeaning(wordId,wordUpdate,meaningUpdate);
			if(uResult==1)
				System.out.println("Successfully Updated..");
			else
				System.out.println("Failed:No such word to Update!!");
			
	}

}

